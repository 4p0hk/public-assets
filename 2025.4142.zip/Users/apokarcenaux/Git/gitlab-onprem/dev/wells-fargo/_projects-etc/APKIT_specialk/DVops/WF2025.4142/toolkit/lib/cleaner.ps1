#requires -Version 5.1
<#
cleaner.ps1 -- WF2025.4142 reversible revert + fixture manufacture. RSAT-free.

Three responsibilities (engagement-spec.md invariants 4 + 5, plus the leader's
fixture-manufacture path):

  A. JOURNAL (Write-CleanupJournal) -- called by the runner BEFORE the writer
     fires. Records {action, group objectGUID, actor SID, was-already-member bool,
     timestamps} to disk, GUID-keyed. The journal is the single source of truth
     for the revert; it is written *before* the mutation so an interrupted run is
     still recoverable.

  B. CLEAN (Invoke-Cleanup) -- journal-driven revert. GUID-keyed (resolves the
     group by objectGUID, never by name, so a rename can't misdirect the revert).
     Idempotent + safe no-op when the actor is already absent. Emits a
     baseline-drift report (did we return the group's membership to baseline?).

  C. MANUFACTURE (Invoke-FixtureManufacture / Invoke-FixtureTeardown) -- the
     LEADER-run path that SEEDS the lab condition (a temp security-enabled global
     group + a Self-Membership ACE for the actor) so the scanner has a real target
     and writer->cleaner can run e2e. Gated behind -ConfirmManufacture, DISALLOWED
     non-interactively. ldifde-EXPORTS every object before ANY create/delete
     (AD Recycle Bin is DISABLED on ecorp -> LDIF is the only recovery path).
     GUID-keyed + reversible. The sub-agent AUTHORS this; the leader RUNS it.

RSAT-FREE throughout: System.DirectoryServices for binds/reads/writes; `ldifde.exe`
(a stock in-box Windows binary, NOT the RSAT AD module) for the safety export.
#>

[CmdletBinding(DefaultParameterSetName = 'Clean')]
param(
    # --- CLEAN set ---
    [Parameter(ParameterSetName = 'Clean')]
    [string]$JournalPath,

    [Parameter(ParameterSetName = 'Clean')]
    [string]$Server,

    [Parameter(ParameterSetName = 'Clean')]
    [System.Management.Automation.PSCredential]$Credential,

    # --- MANUFACTURE set (leader-run; gated) ---
    [Parameter(ParameterSetName = 'Manufacture', Mandatory = $true)]
    [switch]$Manufacture,

    [Parameter(ParameterSetName = 'Manufacture')]
    [string]$GroupName = 'dvops-4142-grp',

    [Parameter(ParameterSetName = 'Manufacture')]
    [string]$GroupOu = 'OU=ecorp-Groups,DC=ecorp,DC=com',

    [Parameter(ParameterSetName = 'Manufacture')]
    [string]$ActorDn,

    [Parameter(ParameterSetName = 'Manufacture')]
    [string]$ManufactureServer,

    # HARD gate: the destructive/creative fixture path runs ONLY with this flag.
    [Parameter(ParameterSetName = 'Manufacture')]
    [switch]$ConfirmManufacture,

    # --- TEARDOWN set (leader-run; reverse of manufacture) ---
    [Parameter(ParameterSetName = 'Teardown', Mandatory = $true)]
    [switch]$Teardown,

    [Parameter(ParameterSetName = 'Teardown')]
    [string]$ManufactureJournalPath,

    [Parameter(ParameterSetName = 'Teardown')]
    [string]$TeardownServer,

    [Parameter(ParameterSetName = 'Teardown')]
    [switch]$ConfirmManufacture2
)

$ErrorActionPreference = 'Stop'   # poc-conventions.md: cleanup is ALWAYS fail-fast (no scope-exempt primitive here).

# Schema GUID for the validated-write "Self-Membership" extended right == the member attr.
$GUID_SELF_MEMBERSHIP = [guid]'bf9679c0-0de6-11d0-a285-00aa003049e2'

function Write-CleanupJournal {
    # Called by the runner BEFORE the writer fires. Persists the revert plan.
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][guid]$GroupObjectGuid,
        [Parameter(Mandatory = $true)][string]$GroupDn,
        [Parameter(Mandatory = $true)][string]$ActorSid,
        [Parameter(Mandatory = $true)][string]$ActorDn,
        [Parameter(Mandatory = $true)][bool]$WasAlreadyMember,
        [string]$Server
    )
    $journal = [pscustomobject]@{
        schema_version     = 1
        action             = 'self-add'
        rule_id            = 'WF2025.4142'
        group_object_guid  = $GroupObjectGuid.ToString()
        group_dn           = $GroupDn
        actor_sid          = $ActorSid
        actor_dn           = $ActorDn
        was_already_member = $WasAlreadyMember
        server             = $Server
        journaled_utc      = (Get-Date).ToUniversalTime().ToString('o')
        reverted_utc       = $null
    }
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $journal | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Path -Encoding ASCII
    Write-Host "[cleaner] journaled revert plan -> $Path (group GUID $($GroupObjectGuid))." -ForegroundColor DarkGray
    return $journal
}

function Get-GroupByGuid {
    # GUID-keyed bind: resolve a group by its objectGUID, NOT by name (rename-safe).
    # Credential-aware (Secure SSPI) so a remote/WinRM -Credential cleanup doesn't double-hop.
    # FALLBACK: a serverless-style <GUID=...> bind can fail under an EXPLICIT credential -- the
    # Secure SSPI bind to a server-scoped <GUID=> path returns "no such object on the server"
    # (the DN bind on the same object + creds works fine, as the writer proves). When -FallbackDn
    # is supplied, retry as a direct DN bind; the caller re-verifies the resolved DN against the
    # journal, so GUID-keyed rename-safety is preserved by that downstream check.
    param([guid]$ObjectGuid, [string]$ServerName, [System.Management.Automation.PSCredential]$Cred, [string]$FallbackDn)
    $mk = {
        param($path)
        if ($Cred) { New-Object System.DirectoryServices.DirectoryEntry($path, $Cred.UserName, $Cred.GetNetworkCredential().Password, [System.DirectoryServices.AuthenticationTypes]::Secure) }
        else       { New-Object System.DirectoryServices.DirectoryEntry($path) }
    }
    $guidStr = $ObjectGuid.ToString('N')   # dashless hex for the GUID-bind form
    $guidLdap = if ($ServerName) { "LDAP://$ServerName/<GUID=$guidStr>" } else { "LDAP://<GUID=$guidStr>" }
    $de = & $mk $guidLdap
    try { $null = $de.RefreshCache(@('distinguishedName')); return $de }
    catch {
        if (-not $FallbackDn) { throw }
        $dnLdap = if ($ServerName) { "LDAP://$ServerName/$FallbackDn" } else { "LDAP://$FallbackDn" }
        $de2 = & $mk $dnLdap
        $null = $de2.RefreshCache(@('distinguishedName'))
        return $de2
    }
}

function Export-ObjectLdif {
    # ldifde safety export BEFORE any delete (Recycle Bin DISABLED on ecorp).
    # ldifde.exe is a stock in-box Windows binary -- NOT the RSAT AD module.
    param([string]$ObjectDn, [string]$OutFile, [string]$ServerName)
    $dir = Split-Path -Parent $OutFile
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $ldifde = Join-Path $env:SystemRoot 'System32\ldifde.exe'
    if (-not (Test-Path -LiteralPath $ldifde)) {
        throw "cleaner: ldifde.exe not found at '$ldifde' -- cannot safely export before delete. ABORT (Recycle Bin is disabled; no LDIF == no recovery)."
    }
    $ldifArgs = @('-f', $OutFile, '-d', $ObjectDn, '-p', 'Base')
    if ($ServerName) { $ldifArgs += @('-s', $ServerName) }
    & $ldifde @ldifArgs | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $OutFile)) {
        throw "cleaner: ldifde export of '$ObjectDn' to '$OutFile' failed (rc=$LASTEXITCODE). ABORT before any delete."
    }
    Write-Host "[cleaner] ldifde-exported '$ObjectDn' -> $OutFile (recovery LDIF)." -ForegroundColor DarkGray
}

function Invoke-Cleanup {
    # Journal-driven, GUID-keyed, idempotent revert. Removes the actor from the
    # group ONLY if the journal says we added them (was_already_member=false) AND
    # they are presently a member. Safe no-op otherwise. Reports baseline drift.
    [CmdletBinding()]
    param([string]$JournalPath, [string]$Server, [System.Management.Automation.PSCredential]$Credential)

    if (-not $JournalPath) { $JournalPath = Join-Path $PSScriptRoot 'wf2025-4142.journal.json' }
    if (-not (Test-Path -LiteralPath $JournalPath)) {
        throw "cleaner: journal not found at '$JournalPath' -- nothing to revert (or revert plan lost)."
    }
    $j = Get-Content -LiteralPath $JournalPath -Raw | ConvertFrom-Json
    $serverName = if ($Server) { $Server } else { [string]$j.server }
    $guid = [guid]$j.group_object_guid

    if ($j.was_already_member) {
        Write-Host "[cleaner] journal says actor was ALREADY a member pre-run -> NOT removing (baseline = member). No-op." -ForegroundColor Yellow
        $j.reverted_utc = (Get-Date).ToUniversalTime().ToString('o')
        $j | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $JournalPath -Encoding ASCII
        return [pscustomobject]@{ Status = 'NoOp-WasMember'; Drift = $false; GroupGuid = $guid.ToString() }
    }

    $groupDe = Get-GroupByGuid -ObjectGuid $guid -ServerName $serverName -Cred $Credential -FallbackDn ([string]$j.group_dn)
    $groupDe.RefreshCache(@('member','distinguishedName'))
    $resolvedDn = [string]$groupDe.Properties['distinguishedName'].Value
    if ($resolvedDn -and ($resolvedDn -ne [string]$j.group_dn)) {
        Write-Host "[cleaner] note: group was renamed since journal ($($j.group_dn) -> $resolvedDn); GUID-bind still correct." -ForegroundColor DarkGray
    }

    $members = @()
    if ($groupDe.Properties['member'].Value) { $members = @($groupDe.Properties['member'].Value) }
    $present = $false
    foreach ($m in $members) { if ([string]$m -ieq [string]$j.actor_dn) { $present = $true; break } }

    if (-not $present) {
        # Idempotent: already absent (maybe a prior cleanup ran) -> safe no-op.
        Write-Host "[cleaner] actor '$($j.actor_dn)' already absent from group -> idempotent no-op." -ForegroundColor Green
        $status = 'NoOp-AlreadyAbsent'
    } else {
        $groupDe.Properties['member'].Remove([string]$j.actor_dn)
        $groupDe.CommitChanges()
        Write-Host "[cleaner] removed actor '$($j.actor_dn)' from group (revert committed on $serverName)." -ForegroundColor Green
        $status = 'Reverted'
    }

    # --- baseline-drift report ---
    $groupDe.RefreshCache(@('member'))
    $membersAfter = @()
    if ($groupDe.Properties['member'].Value) { $membersAfter = @($groupDe.Properties['member'].Value) }
    $stillPresent = $false
    foreach ($m in $membersAfter) { if ([string]$m -ieq [string]$j.actor_dn) { $stillPresent = $true; break } }
    $drift = $stillPresent   # baseline (we added the actor) = actor ABSENT. drift if still present.

    $j.reverted_utc = (Get-Date).ToUniversalTime().ToString('o')
    $j | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $JournalPath -Encoding ASCII

    if ($drift) {
        Write-Warning "[cleaner] BASELINE DRIFT: actor STILL present after revert. Manual remediation required (group GUID $guid)."
    } else {
        Write-Host "[cleaner] baseline restored: actor absent, membership at pre-run baseline. No drift." -ForegroundColor Green
    }
    return [pscustomobject]@{ Status = $status; Drift = $drift; GroupGuid = $guid.ToString() }
}

function Invoke-FixtureManufacture {
    # LEADER-RUN. Seeds the lab condition: create a temp security-enabled GLOBAL
    # group and delegate the actor a Self-Membership ACE so the scanner finds a real
    # target and writer->cleaner can run e2e. ldifde-exports the OU before create so
    # there is a recovery anchor. Writes a manufacture-journal (GUID-keyed) for teardown.
    [CmdletBinding()]
    param([string]$GroupName, [string]$GroupOu, [string]$ActorDn, [string]$Server,
          [switch]$ConfirmManufacture)

    if (-not $ConfirmManufacture) {
        throw "cleaner: fixture manufacture is GATED -- pass -ConfirmManufacture to proceed (it CREATES + DELEGATES AD objects)."
    }
    # DISALLOWED non-interactively: a fixture create must never run unattended.
    if ([Environment]::UserInteractive -eq $false) {
        throw "cleaner: fixture manufacture is DISALLOWED in non-interactive mode (no unattended AD object creation)."
    }
    if (-not $ActorDn) { throw "cleaner: -ActorDn is required for manufacture (the principal to delegate Self-Membership to)." }

    $journalPath = Join-Path $PSScriptRoot 'wf2025-4142.manufacture.journal.json'
    $ldifDir     = Join-Path $PSScriptRoot 'ldif-export'

    # Safety export of the parent OU BEFORE we create anything under it.
    Export-ObjectLdif -ObjectDn $GroupOu -OutFile (Join-Path $ldifDir 'parent-ou.pre-manufacture.ldif') -ServerName $Server

    # Create the group as security-enabled GLOBAL: groupType = 0x80000002 expressed as
    # a SIGNED int32 (-2147483646), NEVER the string '0x80000002' (signed-negative trap).
    $ouLdap = if ($Server) { "LDAP://$Server/$GroupOu" } else { "LDAP://$GroupOu" }
    $ouDe = New-Object System.DirectoryServices.DirectoryEntry($ouLdap)
    $groupDe = $ouDe.Children.Add("CN=$GroupName", 'group')
    $groupDe.Properties['sAMAccountName'].Value = $GroupName
    $GROUP_TYPE_SECGLOBAL = -2147483646   # 0x80000002 as signed int32: SECURITY_ENABLED|GLOBAL
    $groupDe.Properties['groupType'].Value = $GROUP_TYPE_SECGLOBAL
    $groupDe.CommitChanges()
    $groupDe.RefreshCache(@('objectGUID','distinguishedName'))
    $groupGuid = New-Object System.Guid(,([byte[]]$groupDe.Properties['objectGUID'].Value))
    $groupDn   = [string]$groupDe.Properties['distinguishedName'].Value
    Write-Host "[cleaner] manufactured group '$groupDn' (GUID $groupGuid, security-enabled GLOBAL)." -ForegroundColor Green

    # Delegate the actor a Self-Membership validated-write ACE (Self + member ObjectType).
    $actorSid = (Resolve-ActorSid -ActorDn $ActorDn -Server $Server)
    $groupDe.Options.SecurityMasks = [System.DirectoryServices.SecurityMasks]::Dacl
    $groupDe.RefreshCache(@('nTSecurityDescriptor'))
    $sd = $groupDe.ObjectSecurity
    $ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
        $actorSid,
        [System.DirectoryServices.ActiveDirectoryRights]::Self,
        [System.Security.AccessControl.AccessControlType]::Allow,
        $GUID_SELF_MEMBERSHIP
    )
    $sd.AddAccessRule($ace)
    $groupDe.ObjectSecurity = $sd
    $groupDe.CommitChanges()
    Write-Host "[cleaner] delegated Self-Membership ACE to actor SID $($actorSid.Value) on the group." -ForegroundColor Green

    $mj = [pscustomobject]@{
        schema_version    = 1
        action            = 'fixture-manufacture'
        group_object_guid = $groupGuid.ToString()
        group_dn          = $groupDn
        actor_dn          = $ActorDn
        actor_sid         = $actorSid.Value
        server            = $Server
        ldif_export       = (Join-Path $ldifDir 'parent-ou.pre-manufacture.ldif')
        manufactured_utc  = (Get-Date).ToUniversalTime().ToString('o')
        torndown_utc      = $null
    }
    $mj | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $journalPath -Encoding ASCII
    Write-Host "[cleaner] manufacture journal -> $journalPath (teardown reverses this by GUID)." -ForegroundColor DarkGray
    return $mj
}

function Resolve-ActorSid {
    param([string]$ActorDn, [string]$Server)
    if ($ActorDn -match '^(CN|OU|DC)=') {
        $ldap = if ($Server) { "LDAP://$Server/$ActorDn" } else { "LDAP://$ActorDn" }
        $de = New-Object System.DirectoryServices.DirectoryEntry($ldap)
        return New-Object System.Security.Principal.SecurityIdentifier(([byte[]]$de.Properties['objectSid'].Value), 0)
    }
    return (New-Object System.Security.Principal.NTAccount($ActorDn)).Translate([System.Security.Principal.SecurityIdentifier])
}

function Invoke-FixtureTeardown {
    # LEADER-RUN. Reverse of manufacture: ldifde-export the group, then delete it by
    # objectGUID only (GUID-keyed). Gated + non-interactive-disallowed, same as create.
    [CmdletBinding()]
    param([string]$ManufactureJournalPath, [string]$Server, [switch]$ConfirmManufacture)

    if (-not $ConfirmManufacture) {
        throw "cleaner: fixture teardown is GATED -- pass -ConfirmManufacture (it DELETES the seeded AD group)."
    }
    if ([Environment]::UserInteractive -eq $false) {
        throw "cleaner: fixture teardown is DISALLOWED in non-interactive mode."
    }
    if (-not $ManufactureJournalPath) { $ManufactureJournalPath = Join-Path $PSScriptRoot 'wf2025-4142.manufacture.journal.json' }
    if (-not (Test-Path -LiteralPath $ManufactureJournalPath)) {
        throw "cleaner: manufacture journal '$ManufactureJournalPath' not found -- cannot derive the GUID to delete."
    }
    $mj = Get-Content -LiteralPath $ManufactureJournalPath -Raw | ConvertFrom-Json
    $serverName = if ($Server) { $Server } else { [string]$mj.server }
    $guid = [guid]$mj.group_object_guid

    $groupDe = Get-GroupByGuid -ObjectGuid $guid -ServerName $serverName
    $groupDe.RefreshCache(@('distinguishedName'))
    $groupDn = [string]$groupDe.Properties['distinguishedName'].Value

    # MANDATORY ldifde export of the group itself BEFORE delete (Recycle Bin disabled).
    $ldifDir = Join-Path $PSScriptRoot 'ldif-export'
    Export-ObjectLdif -ObjectDn $groupDn -OutFile (Join-Path $ldifDir 'group.pre-delete.ldif') -ServerName $serverName

    $groupDe.DeleteTree()
    Write-Host "[cleaner] deleted seeded group by GUID $guid ('$groupDn'). LDIF recovery anchor saved." -ForegroundColor Green

    $mj.torndown_utc = (Get-Date).ToUniversalTime().ToString('o')
    $mj | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $ManufactureJournalPath -Encoding ASCII
    return [pscustomobject]@{ Status = 'TornDown'; GroupGuid = $guid.ToString(); GroupDn = $groupDn }
}

# --- standalone-run guard (dot-source -> functions only) ---------------------
if ($MyInvocation.InvocationName -ne '.') {
    switch ($PSCmdlet.ParameterSetName) {
        'Manufacture' {
            Invoke-FixtureManufacture -GroupName $GroupName -GroupOu $GroupOu `
                -ActorDn $ActorDn -Server $ManufactureServer -ConfirmManufacture:$ConfirmManufacture
        }
        'Teardown' {
            Invoke-FixtureTeardown -ManufactureJournalPath $ManufactureJournalPath `
                -Server $TeardownServer -ConfirmManufacture:$ConfirmManufacture2
        }
        default {
            Invoke-Cleanup -JournalPath $JournalPath -Server $Server -Credential $Credential
        }
    }
}
