#requires -Version 5.1

<#
notify-jira.ps1 -- sourceable JIRA-comment helper for dvops minimum-trigger PoCs.
Lives in lib\; the runner dot-sources it and passes the SINGLE config object (the
runner config + its jira{} block) to the functions below. There is NO separate
wrapper-config file:

    . "$libDir\notify-jira.ps1"
    if (-not (Assert-JiraReady -Config $cfg)) { exit 3 }   # live auth bad -> abort BEFORE firing
    # ... run the trigger primitive that fires the rule ...
    Send-JiraComment -Config $cfg -Artifact $artifact -ExitCode $rc

$Config carries: rule_name, debug (optional), and jira{ base_url, issue_key, pat,
dry_run, proxy(optional) }. jira.dry_run=true -> build + (debug) preview the comment
but SKIP the POST.

Assert-JiraReady is the fail-fast gate: it runs the /myself auth probe up front and
returns $false ONLY when JIRA is LIVE (dry_run=false) AND the probe fails -- so the
caller aborts before firing rather than fire-and-fail-to-record. No jira block /
dry_run=true => $true (proceed, no probe).

JIRA is a NON-FATAL side-channel: a missing/incomplete jira{} block makes the runner
pass $null and Send-JiraComment no-op -- the trigger's job is to fire the rule, not
to depend on JIRA.

Constraints: PowerShell 5.1 native, ASCII-only, std lib only (Invoke-WebRequest for
the JIRA REST call -- natively Win10-proxy-aware, see Get-ProxyArgs), PAT masked in
console output.
#>

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Get-JiraStamp {
    $utc = (Get-Date).ToUniversalTime()
    try {
        $tz  = [System.TimeZoneInfo]::FindSystemTimeZoneById('Eastern Standard Time')
        $est = [System.TimeZoneInfo]::ConvertTimeFromUtc($utc, $tz)
    } catch {
        $est = (Get-Date)
    }
    return ($est.ToString('MM/dd/yyyy hh:mm tt') + ' EST')
}

function Get-MaskedToken($t) {
    if (-not $t) { return '<empty>' }
    if ($t.Length -le 8) { return ('*' * $t.Length) }
    return ($t.Substring(0,4) + ('*' * ($t.Length - 8)) + $t.Substring($t.Length - 4, 4))
}

function Get-ProxyArgs {
    # Win10-NATIVE proxy awareness for the JIRA REST egress (the toolkit's ONLY HTTP call;
    # all AD work is direct LDAP, never proxied). Honors the endpoint's system proxy -- the
    # per-user WinINET/IE settings that .NET's GetSystemWebProxy() reads, the same source
    # Invoke-WebRequest uses by default -- for THIS target URL, and authenticates to it with
    # the running user's credentials (SSO; the common case for an authenticated corporate
    # proxy that would otherwise 407). An explicit `jira.proxy` in the config overrides.
    # No proxy configured (direct / bypassed) -> empty splat -> Invoke-WebRequest goes direct.
    # Returns a hashtable to splat: `Invoke-WebRequest ... @px`.
    param([Parameter(Mandatory = $true)][string]$Url, $Config)
    $px = @{}
    # (1) explicit override in the config's jira{} wins (e.g. an out-of-band proxy for this run).
    if ($Config -and ($Config.PSObject.Properties.Name -contains 'jira') -and
        ($Config.jira.PSObject.Properties.Name -contains 'proxy') -and [string]$Config.jira.proxy) {
        $px['Proxy'] = [string]$Config.jira.proxy
        $px['ProxyUseDefaultCredentials'] = $true
        return $px
    }
    # (2) else honor the Win10 system (WinINET) proxy for this URL, with SSO proxy auth.
    try {
        $uri = [Uri]$Url
        $sys = [System.Net.WebRequest]::GetSystemWebProxy()
        if ($sys -and -not $sys.IsBypassed($uri)) {
            $proxyUri = $sys.GetProxy($uri)
            if ($proxyUri -and $proxyUri.AbsoluteUri -ne $uri.AbsoluteUri) {
                $px['Proxy'] = $proxyUri.AbsoluteUri
                $px['ProxyUseDefaultCredentials'] = $true
            }
        }
    } catch { }   # proxy detection is best-effort; never block the trigger on it.
    return $px
}

function Test-JiraAuth {
    # Optional auth probe against /myself (matches bunnyops' pre-run probe). Returns
    # $true/$false. Only meaningful in a live (non-dry-run) flow.
    param([Parameter(Mandatory = $true)]$Config)
    $baseUrl = ([string]$Config.jira.base_url).TrimEnd('/')
    $pat     = [string]$Config.jira.pat
    $headers = @{
        'Accept'        = 'application/json'
        'Authorization' = 'Bearer ' + $pat
        'User-Agent'    = 'dvops-notify-ps5'
    }
    try {
        $px = Get-ProxyArgs -Url ($baseUrl + '/rest/api/2/myself') -Config $Config
        $resp = Invoke-WebRequest -Uri ($baseUrl + '/rest/api/2/myself') `
            -Method GET -Headers $headers -UseBasicParsing -TimeoutSec 30 @px
        $me = $resp.Content | ConvertFrom-Json
        Write-Host ('[ OK ] jira auth: ' + $me.name + ' (' + $me.displayName + ')') -ForegroundColor Green
        return $true
    } catch {
        Write-Host ('[FAIL] jira auth probe failed: ' + $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

function Assert-JiraReady {
    # Pre-flight gate, called BEFORE the trigger fires. Returns:
    #   $true  -> safe to proceed (JIRA disabled, OR dry-run, OR live + auth OK)
    #   $false -> JIRA is configured LIVE (dry_run=false) and the auth probe FAILED;
    #             caller should abort before firing so we never fire-and-fail-to-record.
    [CmdletBinding()]
    param($Config)
    if (-not $Config) { return $true }                 # JIRA disabled -> proceed
    if ([bool]$Config.jira.dry_run) { return $true }   # dry-run -> no probe, preview later
    return (Test-JiraAuth -Config $Config)             # live -> auth must pass
}

function Build-JiraComment {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [string]$Artifact,
        $ExitCode
    )
    $stamp = Get-JiraStamp
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('Rule: ' + [string]$Config.rule_name + ' ')
    [void]$sb.AppendLine('Execution Time: ' + $stamp + ' ')
    [void]$sb.AppendLine('User: ' + $env:USERNAME + ' ')
    [void]$sb.AppendLine('Hostname: ' + $env:COMPUTERNAME + ' ')
    if ($null -ne $ExitCode -and ("$ExitCode").Trim().Length -gt 0) {
        [void]$sb.AppendLine('Exit Code: ' + [string]$ExitCode + ' ')
    }
    [void]$sb.Append('Artifact: ' + $Artifact)
    return $sb.ToString()
}

function Send-JiraComment {
    # Post ONE comment recording this trigger execution. Config-gated (no config ->
    # no-op) and dry-run-gated (jira.dry_run=true -> preview only, no POST).
    [CmdletBinding()]
    param(
        $Config,
        [string]$Artifact = '<unspecified>',
        $ExitCode
    )
    if (-not $Config) { return }   # config-gated: no/invalid config -> silent no-op

    $baseUrl  = ([string]$Config.jira.base_url).TrimEnd('/')
    $issueKey = [string]$Config.jira.issue_key
    $pat      = [string]$Config.jira.pat
    $dryRun   = [bool]$Config.jira.dry_run
    $debug    = if ($Config.PSObject.Properties.Name -contains 'debug') { [bool]$Config.debug } else { $false }

    $body = Build-JiraComment -Config $Config -Artifact $Artifact -ExitCode $ExitCode

    if ($debug -or $dryRun) {
        Write-Host ''
        Write-Host '------ jira comment payload ------' -ForegroundColor DarkGray
        Write-Host $body -ForegroundColor White
        Write-Host ('---- issue ' + $issueKey + ' @ ' + $baseUrl + ' (pat ' + (Get-MaskedToken $pat) + ') ----') -ForegroundColor DarkGray
        $pxPreview = Get-ProxyArgs -Url ($baseUrl + '/rest/api/2/issue/' + $issueKey + '/comment') -Config $Config
        if ($pxPreview.ContainsKey('Proxy')) {
            Write-Host ('---- egress: via system proxy ' + $pxPreview['Proxy'] + ' (default creds / SSO) ----') -ForegroundColor DarkGray
        } else {
            Write-Host '---- egress: direct (no system proxy configured for this URL) ----' -ForegroundColor DarkGray
        }
    }

    if ($dryRun) {
        Write-Host '[WARN] DRY-RUN: skipping POST to JIRA.' -ForegroundColor Yellow
        return
    }

    $headers = @{
        'Accept'        = 'application/json'
        'Authorization' = 'Bearer ' + $pat
        'Content-Type'  = 'application/json'
        'User-Agent'    = 'dvops-notify-ps5'
    }
    $payload = @{ body = $body } | ConvertTo-Json -Compress
    $url = $baseUrl + '/rest/api/2/issue/' + $issueKey + '/comment'
    try {
        $px = Get-ProxyArgs -Url $url -Config $Config
        $resp = Invoke-WebRequest -Uri $url -Method POST -Headers $headers `
            -Body $payload -UseBasicParsing -TimeoutSec 60 @px
        $j = $resp.Content | ConvertFrom-Json
        Write-Host ('[ OK ] jira comment posted. id=' + $j.id) -ForegroundColor Green
    } catch {
        Write-Host ('[FAIL] jira comment POST failed: ' + $_.Exception.Message) -ForegroundColor Red
        if ($_.Exception.Response) {
            try {
                $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $errBody = $sr.ReadToEnd()
                Write-Host $errBody -ForegroundColor Red
            } catch { }
        }
    }
}
