# validation proof — WF2025.4142 (Non_Privilege_User_Adding_Themselves_To_An_AD_Group)

**Claim (v1):** the toolkit fires a real Windows Security event **4728** that satisfies every WF2025.4142 SPL predicate — proven by **manual SPL evaluation against a real captured 4728** (testlab-sim; no live `index=os_short` ingestion in v1).

**Result: PASS.** Validated end-to-end on the live `ecorp.com` lab 2026-05-29.

## chain executed

| step | where | result |
|---|---|---|
| **scanner** (read-only, RSAT-free) detects the misconfig | `W11-CORP-02` (Win11 Ent, PS 5.1, **RSAT absent**) → `dc-01` | ✓ 1 ranked candidate: `dvops-4142-grp`, **rank 60 = Self(member) self-membership** |
| **writer** self-adds `Austin.Powers` (explicit `-Credential` → `Subject==Member`) | `W11-CORP-02` → `dc-01` | ✓ `Status=Added, Fired4728=True, SubjectSid==MemberSid` |
| **4728 captured** from the DC Security log | `dc-01` | ✓ see `validation-artifacts/event.json` |
| **cleanup** reverts to baseline | `dc-01` | ✓ member removed, group deleted, re-scan returns no self-addable group |

## captured 4728 vs the SPL predicates (manual eval)

The SPL (`validation-artifacts/rule.spl`) and the captured event (`validation-artifacts/event.json`):

| SPL clause | captured value | verdict |
|---|---|---|
| `EventID="4728"` | `4728` | ✓ |
| `src_nt_domain != "QA-ENT"` | `SubjectDomainName = ECORP` | ✓ |
| `isSameUser` (`SubjectUserName == user`, self-add) | `SubjectUserSid == MemberSid` = `S-1-5-21-…-1330` | ✓ (SID-level self-add) |
| `NOT match(user, "^r.*")` | `user = austin.powers` | ✓ (not `r*`) |
| group scope = security-enabled **global** (precondition; DL/universal emit 4732/4756) | `dvops-4142-grp`, groupType `0x80000002` | ✓ |
| create-when: results > 0 | 1 self-add row | ✓ rule fires |

The **3 discriminating predicates** (cross-field `SubjectUserName==user`, regex-NOT `user!="r*"`, not-equals `src_nt_domain!="QA-ENT"`) are **not `validate.py`-evaluable** → manually mapped above (mandatory). A `validate.py` `EventID=4728`-only match is an explicit **FAIL**, not a pass.

## cross-version matrix

| OS | PowerShell | host | scanner (RSAT-free) | writer → 4728 |
|---|---|---|---|---|
| Win11 Enterprise | 5.1.26100 | `W11-CORP-02` (10.0.2.112) | ✓ detects (rank 60) | ✓ fired Subject==Member |
| Win10 Enterprise | 5.1.19041 | `W10-CORP-04` (10.0.2.104) | ✓ runs RSAT-free (rc=0) | — (same RSAT-free `System.DirectoryServices` code as the proven primary) |
| Win10/11 | 7.x | — | residual: code is `#requires -Version 5.1` (PS7-compatible); no PS7 host provisioned this engagement |

Both endpoints confirmed **RSAT absent** (`Get-Module -ListAvailable ActiveDirectory` → `False`), validating the RSAT-free `System.DirectoryServices`-only design — the toolkit runs on a stock endpoint with no install.

## toolkit hardening surfaced during validation (committed to main)

The live run hardened the credentialed/remote path (each fix driven by an observed failure):
- `16a8960` scanner `-Credential` (portability / remote use)
- `880e66b` `AuthenticationTypes::Secure` on credentialed binds
- `54c1158` bulk DACL read via `DirectorySearcher.SecurityMasks`
- `d0aeb5c` writer `-Credential` threaded through `Resolve-Sid`

## opsec / safety properties exercised

- **dry-run default** — the writer fires only with explicit `-Execute`.
- **self-add invariant** — refuses unless `SubjectUserSid == MemberSid`.
- **reversible** — the seeded fixture (a pre-existing-misconfig stand-in) was GUID-keyed and fully reverted; DC left at baseline.
- **JIRA side-channel** — `wrapper-config.json` stayed `dry_run:true` (no live POST).

## v1.1 — full `runner.ps1` orchestrator validated on Win10 (2026-06-01)

**Result: PASS.** The full orchestrator chain (scan → pick → journal → **write → real 4728** → JIRA dry-run record → autoCleanup revert) ran end-to-end on `W10-CORP-04` (Win10 Ent, PS 5.1.19041.6456), RSAT-free, in **both** drive modes, and against a real captured 4728.

**Mode A (programmatic, JSON-driven), batch-logon execution** — `runner.ps1 -ConfigPath run-config-test.json -Principal "ECORP\Austin.Powers" -Credential <cred>`:
- scan (RSAT-free) → 1 candidate `dvops-4142-grp` (rank 60, Self-membership) for the actor's *real* effective access
- writer → `self-add committed: 'CN=Austin L Powers,…' -> 'CN=dvops-4142-grp,…' (Subject==Member, 4728 fired)`
- captured 4728 on `dc-01`: `SubjectUserName=Austin.Powers`, `SubjectUserSid==MemberSid` (`S-1-5-21-…-1330`), `SubjectDomainName=ECORP`, `TargetUserName=dvops-4142-grp` → manual SPL eval **PASS**
- autoCleanup → `removed actor … from group` → `baseline restored … No drift` → `RUNNER_EXIT rc=0`; post-run membership = 0
- **Mode B (interactive)** confirmed by keyboard over RDP at the endpoint (operator picks the candidate, confirms the arm, confirms the revert).

**Four orchestrator bugs found + hotfixed** (the runner had never been run end-to-end non-interactively/credentialed before — only the standalone components had):
1. **`writer.ps1` mandatory-param dot-source hang** — `[Parameter(Mandatory)]$GroupDn` prompted on `. writer.ps1`, hanging the runner forever in any non-interactive host (WinRM / scheduled task). Fix: drop `Mandatory`, enforce in the standalone-run guard.
2. **`runner.ps1` dot-source param clobber** — dot-sourcing the components re-ran their `param()` blocks, resetting the runner's CLI-bound `$Principal`/`$Credential`/`$Server` to defaults; the JSON merge (gated on `$PSBoundParameters`) then declined to re-apply them, so the writer self-added the *running identity* (Administrator) instead of the actor. Fix: restore CLI-bound values from `$PSBoundParameters` after dot-sourcing.
3. **`cleaner.ps1` GUID-bind under credential** — a `<GUID=…>` bind 400s ("no such object") under an explicit-credential Secure SSPI bind. Fix: fall back to a DN bind (caller re-verifies the DN, preserving rename-safety).
4. **`runner.ps1` journal actor_dn (sam-vs-DN)** — the journal stored the actor in `DOMAIN\sam` form while AD members are DNs, so the cleaner's match missed and falsely reported "already absent" (no revert). Fix: backfill the writer's resolved member DN into the journal.

## proxy-awareness — validated on Win10 (2026-06-01)

`notify-jira.ps1` (the toolkit's **only** HTTP egress) is **natively Win10-proxy-aware** — it honors the endpoint's system (WinINET/IE) proxy for the JIRA URL and authenticates with the running user's credentials (SSO), with an optional explicit `jira.proxy` override. Validated on `W10-CORP-04`:
- **explicit `jira.proxy` override** → `Proxy=http://10.0.1.250:3128, ProxyUseDefaultCredentials=True`; `Invoke-WebRequest` connected **to the proxy** (timed out reaching `10.0.1.250`), not the target.
- **native WinINET detection** → with no proxy: empty (direct); with the system proxy set: auto-detected `Proxy=http://10.0.1.250:3128/, ProxyUseDefaultCredentials=True`.
- **contrast (direct)** → no proxy resolved the target directly: `remote name could not be resolved: 'jira.example.invalid'` (DNS — a distinct error class proving the proxy paths routed through the proxy).
- AD work (`scanner`/`writer`/`cleaner`) is `System.DirectoryServices` over TCP/389 — **never proxied**.
