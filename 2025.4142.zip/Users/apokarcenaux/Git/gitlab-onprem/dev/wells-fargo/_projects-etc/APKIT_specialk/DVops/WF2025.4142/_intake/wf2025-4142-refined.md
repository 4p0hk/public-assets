# refined-idea — WF2025.4142

> v2 autobuild **phase-A refined-idea spec** (`skills/autobuild.md §1.1`, satisfies AP#17).
> Authored 2026-05-29 by refolding the validated `engagement-spec.md` + phase-B proof (`STATUS.md`) into the 6 required sections. The detailed design/invariants/DAG live in `engagement-spec.md`; this is the sharpened idea the DAG was ticketized from.

## expand

Produce a **minimum-trigger PoC** that fires Windows Security event **4728** — a non-privileged domain user adds their **own** account to a security-enabled **global** group — so detection rule **WF2025.4142** (`Non_Privilege_User_Adding_Themselves_To_An_AD_Group`) can be validated. The deliverable is a small, **RSAT-free** PowerShell toolkit (runner → scanner → writer → cleaner) plus a **captured real 4728** and a **manual SPL-predicate eval** proving the rule would fire.

- **who it's for:** the detection-engineering team (consumes the captured 4728 + the reproducible trigger to validate/tune WF2025.4142); and future operators who re-run the **scanner** to detect the self-add misconfig in the wild — the scanner is the portable, reusable star.
- **smallest value MVP:** one real 4728 with `Subject SID == Member SID`, manually eval'd against the SPL predicates, fired by a toolkit that runs on a **stock** Win10/Win11 endpoint (no install) and reverts AD to byte-for-byte baseline. No live Splunk ingestion in v1.

## research

- **prior art:** the bunnyops rule-repo pattern (sibling family); the `dvops-op-template` minimum-trigger-PoC doctrine. The trigger was already proven **e2e in phase-B (2026-05-29)**: temp global-security group created, actor delegated a Self-Membership ACE, actor self-added via LDAP from the beachhead, **4728 captured**, group deleted — DC left clean.
- **libraries/APIs:** `System.DirectoryServices` (`DirectorySearcher`/`DirectoryEntry`) — RSAT-free, runs on stock endpoints. On the beachhead, `pywinrm` + `ldap3` (already tooled in `/opt/adenv`). **NOT** the ActiveDirectory PowerShell module — RSAT is **absent** on ecorp workstations (confirmed), and a stock-endpoint dependency would break the scanner's portability goal.
- **anti-patterns to avoid (baked in):** the signed-negative `groupType` trap (never the string `0x80000002`); treating "a 4728 fired" as a pass (must be Subject==Member self-add); deleting any AD object without an `ldifde` export first (AD Recycle Bin is **DISABLED** on ecorp); risk-score gaming (dvops fires **once**, no gaming — finding risk 60 vs notable threshold 100).

## evaluate

- **toolkit shape — monolith vs orchestrated:** CHOSE orchestrated `runner/scanner/writer/cleaner`. The scanner is reusable + portable (point it at other DCs to find the misconfig); the writer/cleaner are separable; the runner gates everything behind a dry-run default. **Rejected** a monolithic `trigger.ps1` — it couples the portable read-only recon to the destructive write.
- **AD access — RSAT/AD-module vs System.DirectoryServices vs beachhead-LDAP:** CHOSE `System.DirectoryServices` for the endpoint toolkit (RSAT-free portability is the whole point); beachhead LDAP is used only for the phase-B proof. **Rejected** RSAT/AD-module — absent on stock endpoints, install step kills portability.
- **validation path — live Splunk vs testlab-sim + manual eval:** CHOSE testlab-sim + **mandatory manual SPL eval**. No CrowdStrike sensor in this log source; the 3 discriminating predicates (`SubjectUserName==user` self-add, `user!="r*"` regex-NOT, `src_nt_domain!="QA-ENT"` not-equals) are **not** `validate.py`-evaluable. **Rejected** a live `index=os_short` ingestion gate — out of scope for v1.
- **group selection — string vs bitwise:** CHOSE the bitwise LDAP matching rule `(&(objectCategory=group)(groupType:1.2.840.113556.1.4.803:=2147483648)(groupType:1.2.840.113556.1.4.803:=2))`. **Rejected** the string `0x80000002` (signed-negative trap).

## scope

**IN (v1.0.0 MUST include):**
- runner (`trigger.ps1`) orchestrator — programmatic + interactive modes; dry-run default; cautious try/catch.
- scanner (recon, READ-ONLY, portable) — finds security-enabled global groups the principal can self-add to; DENY-aware effective-access; **ranked candidates** (not guarantees).
- writer (prove) — self-add to a feasible group → fires a `Subject==Member` 4728.
- cleaner — journal-driven, GUID-keyed, idempotent, reversible revert.
- `notify-jira.ps1` + `wrapper-config.example.json` (dvops SSoT) — JIRA execution-record, dry-run default, gitignored config holding the PAT.
- the captured real 4728 + `validation-artifacts/{rule.spl,event.json,match-result.json,notes.md}` + `validation-proof.md` with the **mandatory manual SPL-clause mapping**.
- cross-version proof: Win11 PS5.1 (primary), Win10 PS5.1, one PS7 leg.

**OUT (deferred / not v1 — no middle category):**
- live `index=os_short` Splunk ingestion / rule-fire confirmation.
- forest-wide exploit-ranking scan (scanner scope = prove/disprove viable groups in `OU=ecorp-Groups`-class targets only).
- `WriteDacl`/`WriteOwner` two-step indirect-rights exploitation (ranked last, never auto-exploited).
- live JIRA POST (stays `dry_run:true` all engagement; live flip only at the #5 handoff, if at all).
- `payloads/` and `refs/` dirs — pure minimum-trigger PoC.

## goals

Concrete, observable, tool-output-demonstrable criteria (these source the `/goal` block in `docs/wf2025-4142-execute-harness.md`):
- milestone **M1** empties — all of #1–#6 closed (`list_issues state=opened … returns []`).
- `v1.0.0` tag on rule-repo `main` (`git tag --list v1.0.0`).
- **#4 testlab PASS** verdict quotes a real captured 4728 with `Subject SID == Member SID`, `src_nt_domain != QA-ENT`, `user !~ ^r.*`, security-enabled **global** group — manual SPL-clause mapping present. A `validate.py` `EventID=4728`-only match is an explicit **FAIL**.
- **#6 ship-gate PASS** — RSAT-free clean-checkout run + read-only sample-invocation + dry-run-default/cleaner-reverts.
- epic **&2** prepended `🚢 v1 SHIPPED`.

## principles

Locked decisions — the 6 correctness/safety invariants (from adversarial review) + the dvops carve-outs:
1. **Self-add invariant** — the membership write executes **as the member principal**; PASS criterion is `SubjectUserSid == MemberSid`, not merely "a 4728 fired." Explicit `-Credential` must assert cred-SID == member-SID or refuse.
2. **Group scope** — bitwise matching rule (above); re-assert security-enabled-global at write time (domain-local/universal emit 4732/4756, not 4728).
3. **Feasibility = effective access, DENY-aware** — principal SID set = `tokenGroups` ∪ own `objectSid` ∪ well-known SIDs; canonical DACL walk; classify `Self`/`WriteProperty`/`GenericWrite`/`GenericAll` vs `WriteDacl`/`WriteOwner` (ranked last); a matching DENY kills feasibility.
4. **Pin one DC** — resolve a single DC, bind modify + capture to it; pre-check actor is **not already a member** (no-op add emits no 4728).
5. **Reversible cleanup** — journal to disk **before** the write (action, group `objectGUID`, actor SID, was-member bool, timestamps); GUID-keyed, idempotent, safe no-op on already-absent; `ldifde`-export before any delete (Recycle Bin DISABLED); final baseline-drift report.
6. **Runtime** — PS5.1 (stock on ecorp Win11) or PS7, Win10/Win11; **RSAT-free** `System.DirectoryServices`; no endpoint install.

**dvops carve-outs (locked):** direct-push to the rule-repo `main` (no branch, no MR — autobuild AP#3 is scoped to apkit/spine `main`, **not** dvops rule-repos); JIRA is a **non-fatal** side-channel, `dry_run:true` the entire engagement; validation is testlab-sim + manual SPL eval (no live Splunk in v1).

## risk surface (feeds the #6 ship-gate)

Post-ship risks the testlab gate (#4) structurally won't catch — each maps to a #6 acceptance check:
- shipped copy fires a write **without** confirm / not dry-run-default → AD left dirty. *(→ #6 check 3)*
- toolkit picks up a dependency on RSAT/AD-module → fails on a stock endpoint, breaking the portability claim. *(→ #6 check 1)*
- cleaner fails to revert / leaves residue (Recycle Bin disabled → unrecoverable without LDIF). *(→ #6 check 3)*
- README sample command doesn't match impl → a future operator can't reproduce. *(→ #6 check 2)*
- `wrapper-config.json` (holds the PAT) leaks into the repo / isn't gitignored. *(→ gitignore + #6)*
- "4728 fired" mistaken for pass when `Subject != Member`. *(→ #4 manual eval + invariant 1)*
