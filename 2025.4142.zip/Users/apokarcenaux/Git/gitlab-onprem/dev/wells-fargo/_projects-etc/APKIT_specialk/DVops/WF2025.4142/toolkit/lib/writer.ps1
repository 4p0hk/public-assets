#requires -Version 5.1
<#
writer.ps1 -- WF2025.4142 self-add executor (the "prove" step). RSAT-free.

Adds the actor's OWN account to a chosen security-enabled GLOBAL group, executing
AS the member principal, so the resulting Windows Security event 4728 has
    SubjectUserSid == MemberSid   <- THE pass criterion (invariant 1).

This is the ONE component of the toolkit that writes to AD. It is gated: the
runner only calls it after the scanner picks a candidate, the cleaner has
journaled, and (outside dry-run) an explicit confirm. Standalone, it ALSO honours
-WhatIf-style dry-run via -Execute (default: dry-run preview, no write).

Invariants enforced here (engagement-spec.md):
  1. Self-add: assert SubjectUserSid == MemberSid. If -Credential is supplied,
     assert the credential's SID == member SID, else REFUSE (no cross-account add).
  2. Group scope: re-assert security-enabled GLOBAL at write time (bitwise groupType),
     because domain-local/universal emit 4732/4756, NOT 4728.
  4. Pin one DC (caller passes -Server). Pre-check actor is NOT already a member
     (a no-op add emits no 4728) -> signal the runner to pick another candidate.

RSAT-FREE: System.DirectoryServices only. The membership write is a DirectoryEntry
property add on the group's `member` attribute (LDAP modify), committed via
CommitChanges() against the pinned DC, in the actor's own security context.
#>

[CmdletBinding()]
param(
    # Target group DN (the scanner's chosen candidate.DistinguishedName).
    # NOT [Parameter(Mandatory)] -- a mandatory param prompts on DOT-SOURCE (the runner
    # does `. .\writer.ps1`), which hangs forever in any non-interactive host (WinRM /
    # scheduled task). Required-ness is enforced in the standalone-run guard below instead.
    [string]$GroupDn,

    # The member principal to add (must be the ACTING identity). DOMAIN\sam, UPN, or DN.
    # Default = current security context (the self-add identity).
    [string]$Member,

    # Pinned DC (host/FQDN). The runner resolves + passes this. Empty = serverless.
    [string]$Server,

    # Optional explicit credential. If supplied, its SID MUST equal the member SID
    # (this stays a SELF-add); otherwise the write is REFUSED.
    [System.Management.Automation.PSCredential]$Credential,

    # Safety switch. Default is DRY-RUN (build + assert + preview, NO write).
    # The runner passes -Execute only after confirm + journaling.
    [switch]$Execute
)

$ErrorActionPreference = 'Stop'   # poc-conventions.md: writer is fully fail-fast (the membership add is the lone primitive, captured by the runner's try/catch).

$GUID_MEMBER = [guid]'bf9679c0-0de6-11d0-a285-00aa003049e2'

function Resolve-Sid {
    param([string]$Spec, [string]$ServerName, [System.Management.Automation.PSCredential]$Cred)
    if (-not $Spec) { $Spec = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name }
    # Credential-aware DirectoryEntry factory (Secure SSPI bind when -Cred is supplied)
    # so the SID/DN resolution binds don't rely on session delegation (WinRM double-hop).
    $mkDe = {
        param($path)
        if ($Cred) { New-Object System.DirectoryServices.DirectoryEntry($path, $Cred.UserName, $Cred.GetNetworkCredential().Password, [System.DirectoryServices.AuthenticationTypes]::Secure) }
        else       { New-Object System.DirectoryServices.DirectoryEntry($path) }
    }
    if ($Spec -match '^(CN|OU|DC)=') {
        $ldap = if ($ServerName) { "LDAP://$ServerName/$Spec" } else { "LDAP://$Spec" }
        $de = & $mkDe $ldap
        $bytes = $de.Properties['objectSid'].Value
        if (-not $bytes) { throw "writer: member DN '$Spec' has no objectSid (bind failed?)." }
        return [pscustomobject]@{
            Sid = (New-Object System.Security.Principal.SecurityIdentifier(([byte[]]$bytes), 0))
            Dn  = ([string]$de.Properties['distinguishedName'].Value)
        }
    }
    $sid = (New-Object System.Security.Principal.NTAccount($Spec)).Translate([System.Security.Principal.SecurityIdentifier])
    # Look the DN up by SID (needed for the LDAP member-attribute add).
    $rootPath = if ($ServerName) { "LDAP://$ServerName/RootDSE" } else { "LDAP://RootDSE" }
    $defaultNc = [string](& $mkDe $rootPath).Properties['defaultNamingContext'].Value
    $srPath = if ($ServerName) { "LDAP://$ServerName/$defaultNc" } else { "LDAP://$defaultNc" }
    $ds = New-Object System.DirectoryServices.DirectorySearcher((& $mkDe $srPath))
    $ds.Filter = "(objectSid=$($sid.Value))"
    [void]$ds.PropertiesToLoad.Add('distinguishedName')
    $res = $ds.FindOne()
    if (-not $res) { throw "writer: could not resolve DN for member '$Spec' (SID $($sid.Value))." }
    return [pscustomobject]@{ Sid = $sid; Dn = [string]$res.Properties['distinguishedname'][0] }
}

function New-GroupEntry {
    param([string]$Dn, [string]$ServerName, [System.Management.Automation.PSCredential]$Cred)
    $ldap = if ($ServerName) { "LDAP://$ServerName/$Dn" } else { "LDAP://$Dn" }
    if ($Cred) {
        return New-Object System.DirectoryServices.DirectoryEntry($ldap, $Cred.UserName, $Cred.GetNetworkCredential().Password, [System.DirectoryServices.AuthenticationTypes]::Secure)
    }
    return New-Object System.DirectoryServices.DirectoryEntry($ldap)
}

function Invoke-SelfAdd {
    [CmdletBinding()]
    param([string]$GroupDn, [string]$Member, [string]$Server,
          [System.Management.Automation.PSCredential]$Credential, [switch]$Execute)

    # --- resolve member + acting SID ----------------------------------------
    $memberInfo = Resolve-Sid -Spec $Member -ServerName $Server -Cred $Credential
    $memberSid  = $memberInfo.Sid
    $memberDn   = $memberInfo.Dn

    # The SUBJECT of the 4728 is whoever the write runs AS.
    if ($Credential) {
        # Explicit cred path: the SUBJECT will be the credential's identity.
        $subjectInfo = Resolve-Sid -Spec $Credential.UserName -ServerName $Server -Cred $Credential
        $subjectSid  = $subjectInfo.Sid
    } else {
        # Default path: the write runs as the current security context.
        $subjectSid = (Resolve-Sid -Spec ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -ServerName $Server -Cred $Credential).Sid
    }

    # --- INVARIANT 1: self-add. SubjectUserSid MUST equal MemberSid. ----------
    if ($subjectSid.Value -ne $memberSid.Value) {
        throw "writer: REFUSED -- this is not a self-add. Subject SID ($($subjectSid.Value)) != Member SID ($($memberSid.Value)). The 4728 PASS criterion is Subject==Member; a cross-account add fires a 4728 that does NOT match WF2025.4142."
    }

    # --- bind the group + INVARIANT 2: re-assert security-enabled GLOBAL ------
    $groupDe = New-GroupEntry -Dn $GroupDn -ServerName $Server -Cred $Credential
    $groupDe.RefreshCache(@('groupType','member','objectGUID','samAccountName'))
    $groupType = [int64]$groupDe.Properties['groupType'].Value
    $SECURITY_ENABLED = -2147483648   # 0x80000000 as a SIGNED int64 (NEVER the string 0x80000002)
    $GLOBAL_SCOPE     = 2             # 0x00000002
    $isSecurityEnabled = (($groupType -band $SECURITY_ENABLED) -ne 0)
    $isGlobal          = (($groupType -band $GLOBAL_SCOPE) -ne 0)
    if (-not ($isSecurityEnabled -and $isGlobal)) {
        throw "writer: REFUSED -- group '$GroupDn' is not security-enabled GLOBAL at write time (groupType=$groupType). Domain-local/universal emit 4732/4756, not 4728."
    }

    # --- INVARIANT 4: pre-check actor NOT already a member --------------------
    $existing = @()
    if ($groupDe.Properties['member'].Value) { $existing = @($groupDe.Properties['member'].Value) }
    $wasAlreadyMember = $false
    foreach ($m in $existing) {
        if ([string]$m -ieq $memberDn) { $wasAlreadyMember = $true; break }
    }
    if ($wasAlreadyMember) {
        # A no-op add emits NO 4728. Signal the runner to fall through to another candidate.
        Write-Warning "writer: actor '$memberDn' is ALREADY a member of '$GroupDn' -- a re-add emits no 4728. Caller should pick another candidate."
        return [pscustomobject]@{
            Status = 'AlreadyMember'; SubjectSid = $subjectSid.Value; MemberSid = $memberSid.Value
            GroupDn = $GroupDn; MemberDn = $memberDn; WasAlreadyMember = $true; Fired4728 = $false; ExitCode = 4
        }
    }

    # --- preview / dry-run gate ----------------------------------------------
    if (-not $Execute) {
        Write-Host "[writer] DRY-RUN: would self-add member '$memberDn' to group '$GroupDn' on DC '$Server'." -ForegroundColor Yellow
        Write-Host "[writer]   Subject SID == Member SID: $($subjectSid.Value) (self-add asserted OK)" -ForegroundColor DarkGray
        Write-Host "[writer]   group is security-enabled GLOBAL (groupType=$groupType) -- would fire 4728." -ForegroundColor DarkGray
        return [pscustomobject]@{
            Status = 'DryRun'; SubjectSid = $subjectSid.Value; MemberSid = $memberSid.Value
            GroupDn = $GroupDn; MemberDn = $memberDn; WasAlreadyMember = $false; Fired4728 = $false; ExitCode = 0
        }
    }

    # --- the write (the lone primitive) --------------------------------------
    # LDAP add of the member DN to the group's `member` attribute, committed against
    # the pinned DC, in the actor's own context -> fires 4728 with Subject==Member.
    [void]$groupDe.Properties['member'].Add($memberDn)
    $groupDe.CommitChanges()
    Write-Host "[writer] self-add committed: '$memberDn' -> '$GroupDn' (Subject==Member, 4728 fired on $Server)." -ForegroundColor Green

    return [pscustomobject]@{
        Status = 'Added'; SubjectSid = $subjectSid.Value; MemberSid = $memberSid.Value
        GroupDn = $GroupDn; MemberDn = $memberDn; WasAlreadyMember = $false; Fired4728 = $true; ExitCode = 0
    }
}

# --- standalone-run guard (dot-source -> functions only) ---------------------
if ($MyInvocation.InvocationName -ne '.') {
    if (-not $GroupDn) {
        throw "writer: -GroupDn is required when running writer.ps1 standalone (the scanner's chosen candidate DistinguishedName). It is intentionally NOT a Mandatory param so the runner can dot-source this script non-interactively without a prompt."
    }
    $r = Invoke-SelfAdd -GroupDn $GroupDn -Member $Member -Server $Server -Credential $Credential -Execute:$Execute
    $r | Format-List
    exit $r.ExitCode
}
