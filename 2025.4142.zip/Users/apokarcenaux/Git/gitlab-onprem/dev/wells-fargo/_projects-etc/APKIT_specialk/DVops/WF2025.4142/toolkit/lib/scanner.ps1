#requires -Version 5.1
<#
scanner.ps1 -- WF2025.4142 self-add recon (READ-ONLY, portable, RSAT-free).

The reusable star of the toolkit. Dot-source it (the runner does) OR run it
standalone to enumerate, for a given non-privileged principal, the
security-enabled GLOBAL groups that principal can self-add itself to -- the
precondition for firing Windows Security event 4728
(Non_Privilege_User_Adding_Themselves_To_An_AD_Group).

PORTABLE: point -Server at any DC to detect the self-add misconfig in the wild.
          Pass -Credential to bind explicitly (required for remote/WinRM use,
          where the integrated session can't delegate to the DC -- "double-hop").
READ-ONLY: this script performs NO writes. It only binds + reads DACLs.
RSAT-FREE: System.DirectoryServices only (DirectorySearcher / DirectoryEntry).
           NEVER Import-Module ActiveDirectory (absent on stock ecorp endpoints).

DACL read: the group DACLs are read in BULK off the DirectorySearcher (its
SecurityMasks + ntSecurityDescriptor), NOT via per-object DirectoryEntry.Options.
That avoids the credentialed-bind gotcha where a lazy-bound DirectoryEntry returns
a null .Options, and is one round-trip instead of a re-bind per group.

Output: a RANKED list of candidate PSCustomObjects (not guarantees -- effective
access is approximated; the writer falls through to the next candidate on a
runtime failure). Highest rank = most direct self-add right.

Design contract (engagement-spec.md invariants 2 + 3):
- group scope match is the BITWISE rule, never the signed-negative string 0x80000002:
    (&(objectCategory=group)
      (groupType:1.2.840.113556.1.4.803:=2147483648)   # ADS_GROUP_TYPE_SECURITY_ENABLED
      (groupType:1.2.840.113556.1.4.803:=2))            # ADS_GROUP_TYPE_GLOBAL_GROUP
- feasibility = EFFECTIVE access, DENY-aware. Principal SID set =
    tokenGroups (BASE-scope read on the user DN) U own objectSid U well-known SIDs.
- DACL walked in canonical order; a matching DENY kills feasibility.
- rights classified: Self(0x8)+self-membership ObjectType and WriteProperty(0x20)
  on member / GenericWrite / GenericAll rank high; WriteDacl / WriteOwner rank LAST.

Sample (read-only) invocation -- also mirrored in README.md:
    powershell -ExecutionPolicy Bypass -File .\toolkit\scanner.ps1 `
        -Principal "ECORP\Austin.Powers" -SearchBase "OU=ecorp-Groups,DC=ecorp,DC=com"
#>

[CmdletBinding()]
param(
    # Principal to test self-add feasibility for. Accepts DOMAIN\sam, UPN, or a DN.
    # Defaults to the current security context (whoami) when omitted.
    [string]$Principal,

    # OU subtree to scan. Default keeps scope tight to OU=ecorp-Groups-class targets
    # (engagement-spec: NOT a forest-wide exploit-ranking scan). Empty = domain root.
    [string]$SearchBase = "OU=ecorp-Groups,DC=ecorp,DC=com",

    # Pin a single DC (host or FQDN). Empty = serverless bind (DC locator picks one);
    # the runner resolves + pins one explicitly and passes it here.
    [string]$Server,

    # Cap results returned (already ranked). 0 = no cap.
    [int]$MaxResults = 0,

    # Emit only the single top-ranked feasible candidate (writer's default target).
    [switch]$TopOnly,

    # Explicit LDAP bind credential -- portability / remote use (e.g. WinRM double-hop,
    # where the integrated session can't delegate to the DC). Omitted = integrated auth.
    [System.Management.Automation.PSCredential]$Credential
)

$ErrorActionPreference = 'Stop'   # poc-conventions.md rule 1: read-only recon is fully fail-fast.

# --- AD rights / ACE constants (System.DirectoryServices.ActiveDirectoryRights) ---
# Schema GUID for the "member" attribute (validated write on member == self-membership
# when paired with Self). bf9679c0-0de6-11d0-a285-00aa003049e2.
$GUID_MEMBER = [guid]'bf9679c0-0de6-11d0-a285-00aa003049e2'
# All-zero GUID = "applies to the whole object / all properties".
$GUID_ALL    = [guid]'00000000-0000-0000-0000-000000000000'

# Well-known SIDs every authenticated principal effectively carries.
$WELLKNOWN_SIDS = @(
    'S-1-1-0',    # Everyone
    'S-1-5-11',   # Authenticated Users
    'S-1-5-2',    # Network
    'S-1-5-4'     # Interactive
)

function New-DirectoryEntry {
    # Credential-aware DirectoryEntry factory. With -Cred, binds via Secure (SSPI
    # negotiate) so signing-required DCs accept it. No security masks here -- DACLs
    # are read in bulk off the DirectorySearcher (see Find-SelfAddableGroups).
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$ServerName,
        [System.Management.Automation.PSCredential]$Cred
    )
    $ldapPath = if ($ServerName) { "LDAP://$ServerName/$Path" } else { "LDAP://$Path" }
    if ($Cred) {
        return New-Object System.DirectoryServices.DirectoryEntry($ldapPath, $Cred.UserName, $Cred.GetNetworkCredential().Password, [System.DirectoryServices.AuthenticationTypes]::Secure)
    }
    return New-Object System.DirectoryServices.DirectoryEntry($ldapPath)
}

function Resolve-PrincipalContext {
    # Resolve the principal to: objectSid (SecurityIdentifier), distinguishedName,
    # and the full effective-SID set (tokenGroups U own SID U well-known SIDs).
    param(
        [string]$PrincipalSpec,
        [string]$ServerName,
        [System.Management.Automation.PSCredential]$Credential
    )

    # If no principal given, use the current security context.
    if (-not $PrincipalSpec) {
        $PrincipalSpec = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    }

    # Resolve the principal to a SID via NTAccount translation (handles DOMAIN\sam + UPN).
    # A bare DN is handled by binding directly below instead.
    $userDe = $null
    $userSid = $null

    if ($PrincipalSpec -match '^(CN|OU|DC)=') {
        # Looks like a DN -- bind it directly.
        $userDe = New-DirectoryEntry -Path $PrincipalSpec -ServerName $ServerName -Cred $Credential
        $sidBytes = $userDe.Properties['objectSid'].Value
        if (-not $sidBytes) { throw "scanner: principal DN '$PrincipalSpec' has no objectSid (bind failed?)." }
        $userSid = New-Object System.Security.Principal.SecurityIdentifier(([byte[]]$sidBytes), 0)
    } else {
        $nt = New-Object System.Security.Principal.NTAccount($PrincipalSpec)
        $userSid = $nt.Translate([System.Security.Principal.SecurityIdentifier])
        # Look the DN up by objectSid so the tokenGroups BASE read works regardless of input form.
        $rootPath = if ($ServerName) { "LDAP://$ServerName/RootDSE" } else { "LDAP://RootDSE" }
        $rootDse  = New-DirectoryEntry -Path 'RootDSE' -ServerName $ServerName -Cred $Credential
        $defaultNc = [string]$rootDse.Properties['defaultNamingContext'].Value
        $searchRoot = New-DirectoryEntry -Path $defaultNc -ServerName $ServerName -Cred $Credential
        $ds = New-Object System.DirectoryServices.DirectorySearcher($searchRoot)
        $ds.Filter = "(objectSid=$($userSid.Value))"
        $ds.SearchScope = 'Subtree'
        [void]$ds.PropertiesToLoad.Add('distinguishedName')
        $res = $ds.FindOne()
        if (-not $res) { throw "scanner: could not resolve DN for principal '$PrincipalSpec' (SID $($userSid.Value))." }
        $userDn = [string]$res.Properties['distinguishedname'][0]
        $userDe = New-DirectoryEntry -Path $userDn -ServerName $ServerName -Cred $Credential
    }

    $userDn = [string]$userDe.Properties['distinguishedName'].Value

    # tokenGroups is a constructed attr: must RefreshCache it with a BASE-scope read.
    $effectiveSids = New-Object System.Collections.Generic.HashSet[string]
    [void]$effectiveSids.Add($userSid.Value)
    foreach ($w in $WELLKNOWN_SIDS) { [void]$effectiveSids.Add($w) }

    try {
        $userDe.RefreshCache(@('tokenGroups'))
        foreach ($tg in $userDe.Properties['tokenGroups']) {
            $gsid = New-Object System.Security.Principal.SecurityIdentifier(([byte[]]$tg), 0)
            [void]$effectiveSids.Add($gsid.Value)
        }
    } catch {
        Write-Warning "scanner: tokenGroups read failed ($($_.Exception.Message)); falling back to objectSid + well-known SIDs only (feasibility may under-report)."
    }

    return [pscustomobject]@{
        Spec          = $PrincipalSpec
        Sid           = $userSid
        DistinguishedName = $userDn
        EffectiveSids = $effectiveSids
    }
}

function Get-SelfAddRank {
    # Classify a single ALLOW ACE that applies to the principal's effective SID set
    # into a self-add rank. Returns $null if the ACE grants no relevant self-add right.
    #   100 = GenericAll                       (full control -> can add self)
    #    90 = GenericWrite                     (write all props incl. member)
    #    80 = WriteProperty on member attr     (0x20 + member ObjectType -> add anyone, incl self)
    #    70 = WriteProperty on all props       (0x20 + all-props ObjectType)
    #    60 = Self (validated write) on member (0x8 + member ObjectType -> SELF-membership only)
    #    20 = WriteDacl / WriteOwner           (indirect two-step -> ranked LAST)
    param([System.DirectoryServices.ActiveDirectoryAccessRule]$Ace)

    $rights = $Ace.ActiveDirectoryRights
    $ot     = $Ace.ObjectType

    if ($rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::GenericAll))   { return 100 }
    if ($rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::GenericWrite)) { return 90 }

    if ($rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::WriteProperty)) {
        if ($ot -eq $GUID_MEMBER) { return 80 }
        if ($ot -eq $GUID_ALL)    { return 70 }
    }
    if ($rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::Self)) {
        # Self (validated write) is meaningful only against the member attribute here.
        if ($ot -eq $GUID_MEMBER -or $ot -eq $GUID_ALL) { return 60 }
    }
    # Indirect: grants the ability to rewrite the DACL/owner and THEN add self. Two-step.
    if ($rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::WriteDacl) -or
        $rights.HasFlag([System.DirectoryServices.ActiveDirectoryRights]::WriteOwner)) { return 20 }

    return $null
}

function Convert-RankToClass {
    param([int]$Rank)
    switch ($Rank) {
        100 { 'GenericAll' }
        90  { 'GenericWrite' }
        80  { 'WriteProperty(member)' }
        70  { 'WriteProperty(all)' }
        60  { 'Self(member) self-membership' }
        20  { 'WriteDacl/WriteOwner (indirect, two-step)' }
        default { "rank-$Rank" }
    }
}

function Test-GroupSelfAddFeasible {
    # DENY-aware effective-access check on one group's DACL. Walks ACEs in canonical
    # order (DENY before ALLOW per the canonical ordering AD returns); a matching DENY
    # for any relevant right kills feasibility outright. Returns the best ALLOW rank,
    # or $null if not feasible. Takes the parsed ActiveDirectorySecurity (read in bulk
    # off the searcher) rather than a DirectoryEntry.
    param(
        [System.DirectoryServices.ActiveDirectorySecurity]$Sd,
        [System.Collections.Generic.HashSet[string]]$EffectiveSids
    )

    if (-not $Sd) { return $null }
    # Get rules as SecurityIdentifier so we compare SID-to-SID (no name-resolution drift).
    $rules = $Sd.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier])

    $bestAllow = $null
    $denied    = $false

    foreach ($ace in $rules) {
        $idSid = [string]$ace.IdentityReference.Value
        if (-not $EffectiveSids.Contains($idSid)) { continue }   # ACE not for us

        $rank = Get-SelfAddRank -Ace $ace
        if ($null -eq $rank) { continue }                        # not a self-add-relevant right

        if ($ace.AccessControlType -eq [System.Security.AccessControl.AccessControlType]::Deny) {
            # A relevant DENY that reaches us. Canonical DACLs place DENY first, so an
            # ALLOW we already recorded does NOT override a DENY here -> kill feasibility.
            $denied = $true
            break
        } else {
            if ($null -eq $bestAllow -or $rank -gt $bestAllow) { $bestAllow = $rank }
        }
    }

    if ($denied) { return $null }
    return $bestAllow
}

function Find-SelfAddableGroups {
    # Top-level scanner entrypoint. Returns ranked candidate PSCustomObjects.
    [CmdletBinding()]
    param(
        [string]$Principal,
        [string]$SearchBase,
        [string]$Server,
        [int]$MaxResults = 0,
        [switch]$TopOnly,
        [System.Management.Automation.PSCredential]$Credential
    )

    $ctx = Resolve-PrincipalContext -PrincipalSpec $Principal -ServerName $Server -Credential $Credential
    Write-Verbose "scanner: principal $($ctx.Spec) SID=$($ctx.Sid.Value) effective-SIDs=$($ctx.EffectiveSids.Count)"

    # Bind the search base. Empty SearchBase -> domain root via RootDSE.
    if (-not $SearchBase) {
        $rootDse  = New-DirectoryEntry -Path 'RootDSE' -ServerName $Server -Cred $Credential
        $SearchBase = [string]$rootDse.Properties['defaultNamingContext'].Value
    }
    $searchRoot = New-DirectoryEntry -Path $SearchBase -ServerName $Server -Cred $Credential

    $ds = New-Object System.DirectoryServices.DirectorySearcher($searchRoot)
    # BITWISE group-scope match (NEVER the signed-negative string 0x80000002):
    #   2147483648 = SECURITY_ENABLED ; 2 = GLOBAL_GROUP.
    $ds.Filter = '(&(objectCategory=group)(groupType:1.2.840.113556.1.4.803:=2147483648)(groupType:1.2.840.113556.1.4.803:=2))'
    $ds.SearchScope = 'Subtree'
    $ds.PageSize = 200
    # Read the DACL in BULK off the searcher (Dacl+Group+Owner) -> ntSecurityDescriptor.
    $ds.SecurityMasks = [System.DirectoryServices.SecurityMasks]::Dacl `
        -bor [System.DirectoryServices.SecurityMasks]::Group `
        -bor [System.DirectoryServices.SecurityMasks]::Owner
    foreach ($p in @('distinguishedName','samAccountName','objectGUID','objectSid','groupType','ntSecurityDescriptor')) {
        [void]$ds.PropertiesToLoad.Add($p)
    }

    $candidates = New-Object System.Collections.Generic.List[object]

    $results = $ds.FindAll()
    try {
        foreach ($r in $results) {
            $dn = [string]$r.Properties['distinguishedname'][0]

            # Parse the group's DACL from the bulk-read ntSecurityDescriptor bytes.
            if (-not $r.Properties['ntsecuritydescriptor'].Count) { continue }
            $sdBytes = [byte[]]$r.Properties['ntsecuritydescriptor'][0]
            $adSec = New-Object System.DirectoryServices.ActiveDirectorySecurity
            $adSec.SetSecurityDescriptorBinaryForm($sdBytes)

            $rank = Test-GroupSelfAddFeasible -Sd $adSec -EffectiveSids $ctx.EffectiveSids
            if ($null -eq $rank) { continue }

            $guidBytes = $r.Properties['objectguid'][0]
            $objGuid   = New-Object System.Guid(,([byte[]]$guidBytes))
            $sam       = if ($r.Properties['samaccountname'].Count) { [string]$r.Properties['samaccountname'][0] } else { '' }

            $candidates.Add([pscustomobject]@{
                Name              = $sam
                DistinguishedName = $dn
                ObjectGuid        = $objGuid
                Rank              = $rank
                RightClass        = (Convert-RankToClass $rank)
                PrincipalSid      = $ctx.Sid.Value
                Server            = $Server
                Note              = 'ranked candidate, not a guarantee -- effective access approximated'
            })
        }
    } finally {
        $results.Dispose()
    }

    # Sort highest-rank first; that is the writer's preferred-to-fallthrough order.
    $ranked = $candidates | Sort-Object -Property Rank -Descending
    if ($MaxResults -gt 0) { $ranked = $ranked | Select-Object -First $MaxResults }
    if ($TopOnly)          { $ranked = $ranked | Select-Object -First 1 }
    return $ranked
}

# --- standalone-run guard ----------------------------------------------------
# When dot-sourced (the runner does `. .\scanner.ps1`), $MyInvocation.InvocationName
# is '.' and we DON'T auto-run -- we only export the functions. When invoked
# directly, we run the scan and emit the ranked candidate table.
if ($MyInvocation.InvocationName -ne '.') {
    $found = Find-SelfAddableGroups -Principal $Principal -SearchBase $SearchBase `
        -Server $Server -MaxResults $MaxResults -TopOnly:$TopOnly -Credential $Credential
    if (-not $found -or $found.Count -eq 0) {
        Write-Host "[scanner] no security-enabled GLOBAL groups self-addable by '$Principal' under '$SearchBase'." -ForegroundColor Yellow
    } else {
        Write-Host "[scanner] $($found.Count) ranked self-add candidate(s) (highest rank = most direct):" -ForegroundColor Green
        $found | Format-Table Rank, RightClass, Name, DistinguishedName -AutoSize
    }
    # Emit objects to the pipeline too (for programmatic capture).
    $found
}
