#!/usr/bin/env python3
"""validate.py — dvops testlab-sim path validator.

COPIED INTO RULE REPO during testlab gate (issue 4). Used ONLY for the
testlab-sim validation path (non-CS log sources). For CS-path
engagements, validation happens via NGS API (see reference/cs-validation.md);
this script is unused.

Inputs:
    --spl PATH         the rule's SPL query file
    --event PATH       a synthesized log event JSON file
    --out PATH         where to write match result + matched fields

Behavior:
    1. parse the SPL to extract match conditions (fields + values + regex)
    2. evaluate against the synthesized event
    3. report: match=true/false + which conditions matched
    4. write JSON output for commit to rule-repo as validation-proof artifact

Note on SPL evaluator:
    This scaffold uses a MINIMAL hand-rolled SPL parser sufficient for
    typical detection-rule SPL (search ... | where ... | eval ...).
    Complex SPL (lookups, stats, transactions) may exceed the parser's
    coverage — operator's call whether to extend the parser or fall
    back to manual eval.

    Future enhancement candidate (T-item): integrate a real SPL evaluator
    (splunk-sdk-python's mock eval, or an open-source alternative).
"""
import argparse
import json
import re
import sys
from pathlib import Path


def parse_spl_conditions(spl_text):
    """extract field=value and field=regex conditions from SPL."""
    conditions = []
    for match in re.finditer(r'(\w+)\s*=\s*"?([^\s"]+)"?', spl_text):
        field, value = match.group(1), match.group(2)
        if field.lower() in ('search', 'index', 'sourcetype', 'where', 'eval'):
            continue
        conditions.append((field, value))
    return conditions


def evaluate(event, conditions):
    """check if event satisfies all conditions."""
    matched = []
    failed = []
    for field, value in conditions:
        ev_value = event.get(field, '')
        if isinstance(ev_value, (int, float)):
            ev_value = str(ev_value)
        pattern = re.escape(value).replace(r'\*', '.*')
        if re.fullmatch(pattern, ev_value, re.IGNORECASE):
            matched.append({'field': field, 'value': value, 'event_value': ev_value})
        else:
            failed.append({'field': field, 'value': value, 'event_value': ev_value})
    return {
        'match': len(failed) == 0,
        'matched_conditions': matched,
        'failed_conditions': failed,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--spl', required=True, type=Path)
    p.add_argument('--event', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    args = p.parse_args()

    spl_text = args.spl.read_text()
    event = json.loads(args.event.read_text())
    conditions = parse_spl_conditions(spl_text)
    result = evaluate(event, conditions)
    result['spl_path'] = str(args.spl)
    result['event_path'] = str(args.event)
    result['conditions_parsed'] = [{'field': f, 'value': v} for f, v in conditions]

    args.out.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    sys.exit(0 if result['match'] else 1)


if __name__ == '__main__':
    main()
