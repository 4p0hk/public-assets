# engagement-spec — WF2025.4142

> dvops per-engagement spec. Input contract for `/autobuild <path-to-this-file>`.
> Authored 2026-05-29 from validated A-side recon (see STATUS.md) + adversarial design review.

## metadata
| field | value |
|---|---|
| rule-id | `WF2025.4142` |
| rule-id-dashed | `wf2025-4142` |
| rule-name | `Non_Privilege_User_Adding_Themselves_To_An_AD_Group` |
| product | Splunk ES / RBA (finding risk 60; tenant notable threshold 100 — dvops fires **once**, no risk-gaming) |
| log-source | **windows-security** (Windows Event Log → Splunk; event **4728**) |
| validation-path | **testlab-sim** (windows-security is not CrowdStrike → testlab-sim per `reference/testlab-sim.md`) |
| scaffold flavor | Windows → `trigger.ps1` (PowerShell) |
| jira-base-url | `https://your-jira-host.example.net` (placeholder — execution-record side-channel; operator fills at handoff, if at all) |
| jira-issue-key | `PROJ-0000` (placeholder; **PAT goes in the gitignored `wrapper-config.json`, never here**) |

## splunk query (the logic we satisfy; NOT a live target)
```spl
index="os_short" (sourcetype="WinEventLog" OR sourcetype="XmlWinEventLog")
EventID=4728 src_nt_domain!="QA-ENT" SubjectUserName=user user!="r*"
```
Semantics: a **non-privileged** domain user adds **their own** account to a **security-enabled global** group → event **4728**, where the actor (`SubjectUserName`) equals the member added (self-add), the domain is not `QA-ENT`, and the user does not start with `r`.

## validation path declaration
**testlab-sim.** No CrowdStrike sensor in this log source. v1 claim = **"WF2025.4142 *would* fire against a representative 4728"** — proven by manual SPL evaluation against a real captured 4728 (we can already generate one — see STATUS.md A-side proof), NOT by a live `index=os_short` fire. A live-Splunk-ingestion claim is explicitly **out of scope** for v1.

## push policy (VERBATIM — transcribe into issue 3 + issue 4 sub-agent briefs)
> **This is a dvops rule-repo. Push direct to main. Do NOT create a feature branch. Do NOT open an MR. Velocity matters more than review overhead for PoC repos. (Autobuild anti-pattern #3 does NOT apply here — that rule scopes to apkit v2/v3 + spine main, NOT to dvops rule-repos.)**

## minimum trigger primitive (design — informs issue 1)
For this rule the primitive is inseparable from its **precondition**: you cannot self-add without a group the actor may self-add to. So the primitive decomposes into a small, single-piece PowerShell toolkit (orchestrated, not a framework):

- **runner** (`trigger.ps1`) — orchestrator. Two launch modes: **programmatic** (auto-derive everything from the host, run scan → pick → prove → cleanup behind an explicit confirm flag) and **interactive** (scan → present candidates → confirm → prove → offer cleanup). Cautious try/catch; dry-run by default.
- **scanner (recon, READ-ONLY)** — the reusable star; **portable** (can be pointed at other DCs to detect the misconfig in the wild). Finds **security-enabled global** groups the current/specified non-priv principal can self-add to. **Minimal scope: prove/disprove viable groups exist in `OU=ecorp-Groups`-class targets** — not a forest-wide exploit-ranking scan.
- **writer (prove)** — self-add to a chosen feasible group → fires 4728. For our e2e lab validation.
- **cleaner** — journal-driven reversible revert.

### correctness/safety invariants (from adversarial review — MUST hold)
1. **Self-add invariant:** the membership write executes **as the member principal**, so the 4728 `SubjectUserSid == MemberSid`. If an explicit `-Credential` is supplied, assert cred-SID == member-SID or refuse. **PASS criterion is `SubjectUserSid == MemberSid`, not merely "a 4728 fired."**
2. **Group scope:** select with the bitwise matching rule `(&(objectCategory=group)(groupType:1.2.840.113556.1.4.803:=2147483648)(groupType:1.2.840.113556.1.4.803:=2))` — never the string `0x80000002` (signed-negative trap). Re-assert security-enabled-global at write time (domain-local/universal emit 4732/4756, not 4728).
3. **Feasibility = EFFECTIVE access, DENY-aware.** Principal SID set = `tokenGroups` (BASE-scope read on the user DN, byte[]→SID) ∪ own objectSid ∪ well-known SIDs (`S-1-1-0` Everyone, `S-1-5-11` Authenticated Users, Domain Users via primaryGroupID). Walk the DACL in canonical order; a matching DENY kills feasibility. Classify rights: `Self`(0x8)+ObjectType `bf9679c0-…049e2` = self-only; `WriteProperty`(0x20) on member / GenericWrite / GenericAll = add-anyone (also self); `WriteDacl`/`WriteOwner` = indirect (two-step), rank last. Scanner output = **ranked candidates, not guarantees** — writer falls through to the next on runtime failure.
4. **Pin one DC.** Resolve a single DC; bind both the modify and any event capture to it. Pre-check the actor is **not already a member** (no-op add emits no 4728) → else pick another candidate.
5. **Reversible cleanup.** Journal to disk **before** the write (action, group `objectGUID`, actor SID, was-already-member bool, timestamps); cleanup is journal-driven, GUID-keyed, idempotent, safe no-op on already-absent; final baseline-assertion reports drift.
6. **Runtime:** PS5.1 (confirmed on ecorp Win11) or PS7, Win10/Win11. **RSAT-free — use `System.DirectoryServices` (DirectorySearcher/DirectoryEntry), NOT the ActiveDirectory module.** (RSAT/AD-module is ABSENT on ecorp workstations — confirmed — and a stock-endpoint dependency hurts the scanner's portability goal.) Read DACLs via `DirectoryEntry` with `Options.SecurityMasks = Dacl,Group,Owner` → `ObjectSecurity.GetAccessRules(... [NTAccount]/[SecurityIdentifier])` for the `ActiveDirectoryRights`/`ObjectType`/`AceType`/DENY classification; tokenGroups via base-scope `DirectoryEntry` on the user DN. No install step on the endpoint.

## JIRA execution record (non-fatal side-channel)
dvops ships its **OWN** `notify-jira.ps1` + `wrapper-config.example.json` (template golden rule 4 — this is the SSoT *for dvops*; do **NOT** lift-by-path from bop-template, whose poster is embedded in its monolithic `Run-RuleId.ps1`). It posts **ONE** comment recording the trigger fire (Rule / ExecTime / User / Host / ExitCode / Artifact). Wiring into our **bespoke** runner→scanner→writer→cleaner (we do NOT use canonical `trigger.ps1`):

- **runner pre-flight**, before scanner/writer touch AD:
  ```
  . "$PSScriptRoot\notify-jira.ps1"
  $JiraCfg = Get-WrapperConfig -Quiet
  if (-not (Assert-JiraReady -Config $JiraCfg)) { <abort — do NOT fire> }
  ```
  `Assert-JiraReady` returns `$false` **only** when LIVE (`dry_run:false`) **and** the `/myself` probe fails → fail-fast *before* firing (never fire-and-fail-to-record). No-config / dry-run → `$true` (proceed).
- **execution record after the WRITER fires the real 4728** (that IS the execution moment):
  ```
  Send-JiraComment -Config $JiraCfg -Artifact $WriterPath -ExitCode $writerRc
  ```
  `dry_run:true` → build + preview only, **no POST**.
- **non-fatal contract:** a missing/preview/malformed config must **NEVER** block the 4728 fire or the testlab-sim validation. It records the *writer's 4728 execution*, not a Splunk/CS fire → issue-4's manual SPL-predicate validation is **unchanged**.
- `wrapper-config.json` ships with placeholders + `dry_run:true`, is **gitignored** (holds the PAT), and **stays dry-run the entire engagement**; live flip only at issue-5 handoff (if at all).

## code scaffolds + reference pointers
- scaffold: `_git-workspaces/dvops-op-template/code-scaffolds/trigger.ps1`, `validate.py`, **`notify-jira.ps1` + `wrapper-config.example.json`** (JIRA execution-record helper, dvops SSoT — see above) — copy + token-substitute `{{RULE_ID}}`=WF2025.4142, `{{RULE_ID_DASHED}}`=wf2025-4142, `{{TRIGGER_PRIMITIVE}}`=non-priv self-add to a self-addable security-enabled global group (4728). `wrapper-config.example.json` → `wrapper-config.json` (placeholders, `dry_run:true`), gitignored.
- refs: `_git-workspaces/dvops-op-template/reference/testlab-sim.md` (validation), `_git-workspaces/dvops-op-template/reference/spl-primer.md` (design).

## lab host
Validation host = **`W11-CORP-02`** (PVE vmid 332, `10.0.2.112`, Win11 Enterprise, sandbox) — domain-joined, reachable from the `vm_5002` beachhead via **WinRM/5985** (workstation subnet `10.0.2.0/24`, routed via ecorp-router `10.0.1.1`; RDP closed). DC = `dc-01` @ `10.0.1.10` (`ecorp.com`). Actor = `Austin.Powers` / `PowersPass` (validated; non-priv; not `^r`). Scanner is RSAT-free → **no workstation prep needed**. dc-01 + the pinned workstation + all 18 Win10/11 IPs are now in `reference/lab-inventory.json`.

## lab test fixture (PEARL is ours to shape — for `/testlab` e2e)
PEARL/ecorp is our environment; we **seed** the condition to exercise the toolkit e2e:
- create/confirm a non-priv test user (or use `Austin.Powers`) and a **security-enabled global** group the user can self-add to (delegate Self-Membership) — carefully, on `dc-01`, GUID-keyed + reversible (capture full DACL, restore byte-for-byte; delete by objectGUID only; gated behind a distinct `-ConfirmManufacture`, disallowed in non-interactive mode).
- this gives the **scanner** a real target to find and lets **writer→cleaner** run end-to-end. Different outcome expectations (feasible vs not; self vs non-self; r* exclusion; wrong scope) are exercised via `/testlab` by seeding the relevant users/groups.
- AD Recycle Bin on ecorp = **DISABLED (confirmed)** → the manufacture path MUST `ldifde`-export the group (and any modified object) before any delete; restore-from-LDIF is the recovery path, not the Recycle Bin.

## version coverage (cross-version test matrix)
The scanner must be proven across the versions in play; test hosts may be provisioned as needed (operator-approved). RSAT-free `System.DirectoryServices` is chosen so the SAME code runs everywhere with no per-host install.

| OS | PowerShell | test host (sandbox, PVE-snapshot-revertible) |
|---|---|---|
| Win11 Enterprise | 5.1 (stock) | `W11-CORP-02` (pve 332, `10.0.2.112`) — primary |
| Win10 Enterprise | 5.1 (stock) | `W10-CORP-04` (pve 324, `10.0.2.104`) |
| Win10/Win11 | 7.x | install `pwsh` on a sandbox host for the PS7 leg; verify `System.DirectoryServices` behaves on PS7-on-Windows |

Testlab gate (issue 4) records a PASS **per cell** (scanner finds the seeded group; writer fires a `Subject==Member` 4728; cleaner reverts to baseline). All reachable from the `vm_5002` beachhead via WinRM/5985.

## issue DAG — milestone `M1: trigger + validate`, epic `WF2025.4142 — minimum trigger PoC`

| # | title | labels | blocked_by | acceptance |
|---|---|---|---|---|
| 1 | `design — parse SPL, identify minimum trigger primitive` | `type::task` `stage::design` `status::ready` `area::detection` | — | SPL parsed; primitive = the scanner→self-add→cleanup decomposition above; non-evasion confirmed; log-source + testlab-sim path confirmed; design note posted with PROPOSED PRIMITIVE + RATIONALE + the 6 invariants; pin DC + lab workstation from inventory |
| 2 | `[GATE] minimum-viable trigger confirmed` | `type::task` `stage::vetted` `status::blocked` | 1 | **Leader only.** Confirms primitive is minimal + non-evasive + invariants present; PASS comment closes gate; FAIL → `health::needs-attention`, don't close |
| 3 | `impl — build trigger + run on lab host` | `type::feature` `stage::vetted` `status::blocked` `area::poc` | 2 | Copy scaffolds **incl. `notify-jira.ps1` + `wrapper-config.example.json` → `wrapper-config.json`** (placeholders, `dry_run:true`) and **gitignore `wrapper-config.json`**; build runner/scanner/writer/cleaner per invariants; **wire JIRA — dot-source `notify-jira`, `Assert-JiraReady` pre-flight in the runner, `Send-JiraComment` after the writer's 4728**; **commit to rule-repo main (direct push, no MR — see push policy)**; seed lab fixture; run across the version matrix as `Austin.Powers`; smoke artifacts (scanner finds seeded group; writer fires `Subject SID==Member SID` 4728; cleaner reverts; **JIRA dry-run PREVIEW emitted, NO live POST**). Report: commit hash, lab host(s), artifacts |
| 4 | `[GATE] M1 testlab — trigger fired the rule` | `testlab::gate` `type::task` `stage::vetted` `status::blocked` | 3 | **testlab-sim path:** capture the **real 4728** (preferred over synthetic) → `validation-artifacts/{rule.spl,event.json,match-result.json,notes.md}` + `validation-proof.md`, committed to main. `validate.py` covers the AND-able subset; the **three discriminating predicates are NOT validate.py-evaluable** (cross-field `SubjectUserName==user` equality, regex-NOT `user!="r*"`, not-equals `src_nt_domain!="QA-ENT"`) → **MANUAL eval section mapping each SPL clause to the captured 4728 fields is mandatory.** A `validate.py` match on EventID=4728 alone is an explicit **FAIL**, not a pass. PASS = all clauses satisfied (validate.py subset + manual eval) |
| 5 | `[GATE] WF2025.4142 v1.0.0 — PoC ship readiness` | `testlab::gate` `type::task` `stage::vetted` `status::blocked` | 4 | **Leader only.** All M1 issues closed; testlab passed; rule repo has trigger toolkit + `validation-proof.md` + `STATUS.md`; epic description prepended `🚢 v1 SHIPPED`; `v1.0.0` tag on rule-repo main; then `/loop stop` + `/stash` + exit. **JIRA live flip (`dry_run:false` + live post) happens HERE only, if at all — otherwise stays dry-run.** |

## notes
- `/intake` creates the standard label set if absent (status/stage/type/testlab/health/area + `priority::high`).
- STATUS.md is a v1 closing artifact (spine rule-repo convention).
- No `payloads/`/`refs/` dirs — pure minimum-trigger PoC.
