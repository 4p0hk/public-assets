# WF2025.4142
Detection for a non-privileged user adding **their own** account to a security-enabled
**global** group — Windows Security event **4728** with `Subject == Member`. This kit fires
that 4728 as the minimum primitive (RSAT-free, no install) so the rule can be validated.

## layout
```
toolkit/
  runner.ps1          <- entry point: run this
  config.json         <- the ONE config (copy from config.example.json; gitignored, holds the PAT)
  lib/                <- components, dot-sourced by the runner
    scanner.ps1   writer.ps1   cleaner.ps1   notify-jira.ps1
```
The runner **checks this layout on start and fails fast** (exit 2, precise "what's missing") if
`config.json` or any `lib\` component is absent — it never blows through into downstream errors.

## config — one file, full-auto + JIRA
Copy `config.example.json` → `config.json` next to `runner.ps1`. Everything domain-side is
`auto`; you only fill the `jira` block (url / ticket / PAT):
```json
{
  "mode": "interactive",
  "principal": "auto",
  "searchBase": "auto",
  "server": "auto",
  "selection": { "strategy": "top", "value": "" },
  "execute": false,
  "autoCleanup": false,
  "rule_name": "WF2025.4142 Non_Privilege_User_Adding_Themselves_To_An_AD_Group",
  "jira": { "base_url": "https://jira.example.net", "issue_key": "PROJ-1234", "pat": "YOUR_PAT", "dry_run": true }
}
```
- **`auto`** = derive from the running user: `principal` = current context (whoami), `searchBase` =
  domain root (RootDSE), `server` = DC locator. No domain/user values to set.
- **JIRA** stays `dry_run:true` (preview, no POST) until you flip it; it's natively
  **Win10-proxy-aware** (honors the system proxy, or set `jira.proxy`). The actor credential is
  **never** in the config — omit it (integrated) or pass `-Credential` on the CLI.

## run — two modes
Run as the actor (integrated auth) on a domain-joined host. **Dry-run by default** — add
`-Execute` (or `execute:true` in config) to arm.
```powershell
# (1) INTERACTIVE — scan, pick the target group from the ranked list, confirm, revert
.\runner.ps1 -Mode Interactive -Execute

# (2) PROGRAMMATIC — unattended, config-driven (set execute:true + autoCleanup:true in config.json)
.\runner.ps1 -Mode Programmatic
```
Remote / not logged in as the actor: add `-Principal "DOMAIN\actor" -Credential (Get-Credential DOMAIN\actor)`.

**PASS:** a real 4728 with `SubjectUserSid == MemberSid`, `src_nt_domain != "QA-ENT"`, on a
security-enabled **global** group, actor not matching `^r.*`.

## components
| file | role |
|---|---|
| `runner.ps1` | orchestrator: layout-check → JIRA pre-flight → DC pin → scan → pick → journal → write → JIRA record → cleanup; **dry-run default** |
| `lib/scanner.ps1` | READ-ONLY recon; ranks security-enabled global groups the principal can self-add to (DENY-aware) |
| `lib/writer.ps1` | self-add executor; asserts `SubjectUserSid == MemberSid` (the 4728 PASS criterion) |
| `lib/cleaner.ps1` | journal-driven, GUID-keyed idempotent revert (`ldifde`-export before any delete) |
| `lib/notify-jira.ps1` | non-fatal JIRA execution-record; dry-run default + Win10-proxy-aware |

## sql query
```
index="os_short" (sourcetype="WinEventLog" OR sourcetype="XmlWinEventLog")
    TERM(4728) EventID="4728" src_nt_domain!="QA-ENT" 
| eval 
    user=lower(user)
    , SubjectUserName=lower(SubjectUserName)
    , isSameUser=if(SubjectUserName==user, "true", "false") 
| where 
    NOT match(user, "^r.*") 
    AND isSameUser="true" 
| stats 
    count
    , earliest(_time) AS earliest_time
    , latest(_time) AS latest_time
    , values(user_bunit) AS user_bunit
    , values(user_nick) As nick
    , values(SubjectUserName) AS SubjectUserName
    , values(EventID) AS event_id
    , values(TargetUserName) AS TargetUserName
    , values(src_nt_domain) AS src_nt_domain
    , values(action) AS action
    BY 
    user
    , sourcetype 
| `SCD_Exclusion_List("WF2025.4142.Non_Privilege_User_Adding_Themselves_To_An_AD_Group", "user")` 
| `SCD_Exclusion_List("WF2025.4142.Non_Privilege_User_Adding_Themselves_To_An_AD_Group", "TargetUserName")` 
| `SCD_Exclusion_List("WF2025.4142.Non_Privilege_User_Adding_Themselves_To_An_AD_Group", "src_nt_domain")` 
| fillnull value="unknown" nick
| convert
    timeformat="%Y-%m-%dT%H:%M:%S%z"
    ctime(earliest_time)
    , ctime(latest_time) 
| `identity_normalization("user")`
```

## details
```
1. Entities and threat objects
*Entities
Entity type: user
Entity: user_normalized
Finding risk score: 60
Output:

Threat objects: none specified

2. Intermediate finding details
Title: Non_Privilege_User_Adding_Themselves_To_An_AD_Group by [$user$]
Description: A non-privilege user [$user$] added own account to a Production Security Enabled Group [$TargetUserName$]
Investigation type: default
Security domain: Access
Severity: Low

3. Drill-down / extraction
Drill-down name: View related events
Search: (not specified)
Earliest Offset: $info_min_time$
Latest Offset: $info_max_time$
Identity extraction: user
Asset extraction: not specified
File extraction: not specified
URL extraction: not specified

4. Annotations
blank

5. Time range
Timestamp: Event time
Earliest: -1h@h
Latest: @h
Cron schedule: 36 * * * *
Scheduling: Real-time (Continuous)
Schedule window: 5
Schedule priority: Default

6. Conditions
Create when: Number of Results is greater than 0
Create: Once

7. Throttling
Window duration: 1 hour(s)
Fields to group by: user, sourcetype
```
