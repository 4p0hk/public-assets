#requires -Version 5.1
<#
runner.ps1 -- WF2025.4142 minimum-trigger orchestrator. RSAT-free.

Orchestrates the bespoke runner -> scanner -> writer -> cleaner toolkit that fires
Windows Security event 4728 (a non-privileged user self-adds to a security-enabled
GLOBAL group), so detection rule WF2025.4142
(Non_Privilege_User_Adding_Themselves_To_An_AD_Group) can be validated.

Trigger primitive: non-priv self-add to a self-addable security-enabled global
group (event 4728).

This is NOT the canonical monolithic trigger.ps1 -- it is a thin orchestrator that
dot-sources the four components. It owns: DC pinning, the JIRA pre-flight gate
(BEFORE any AD touch), the scan->pick->journal->write sequence, the post-write JIRA
execution record, and the cleanup offer. DRY-RUN BY DEFAULT -- it performs NO write
unless -Execute is passed (programmatic) or the operator confirms (interactive).

Two launch modes:
  -Mode Programmatic : auto-derive everything; scan -> selection-strategy candidate
                       -> (if -Execute) journal -> write -> JIRA record ->
                       (if -AutoCleanup) revert. No prompts. -Execute is REQUIRED for
                       any write; default is preview.
  -Mode Interactive  : scan -> present ranked candidates -> confirm -> journal ->
                       write -> JIRA record -> offer cleanup. (DEFAULT.)

Two drive surfaces, baked in (v1.1):
  (A) PROGRAMMED via JSON  : -ConfigPath run-config.json drives an unattended run
                             (mode/principal/searchBase/server/selection/execute/
                             autoCleanup/jiraConfigPath). Explicit CLI params OVERRIDE
                             the JSON. CREDENTIALS ARE NEVER IN THE JSON (pass -Credential).
  (B) INTERACTIVE          : numbered ranked-candidate list -> Read-Host select -> confirm.

Auto-domain (v1.1): an unspecified / 'auto' search base passes through as empty, so
the scanner derives the RUNNING USER's domain root (RootDSE defaultNamingContext) --
NOT a hardcoded OU=ecorp-Groups,DC=ecorp,DC=com. Pass -SearchBase / set searchBase in
the JSON to tighten scope.

-Credential (v1.1): an explicit PSCredential is threaded into the scanner, the writer,
AND Resolve-PinnedDc (credential-aware + AuthenticationTypes::Secure) so the toolkit
works remotely / over WinRM where the integrated session can't delegate to the DC
("double-hop"). Omitted = integrated auth (run-as-actor) -- unchanged from v1.0.

Invariants are enforced in the components (scanner: scope+feasibility; writer:
self-add SID assert + scope re-assert + not-already-member; cleaner: journal-first +
GUID-keyed reversible). The runner wires them in the safe order + gates the write.
#>

[CmdletBinding()]
param(
    [ValidateSet('Interactive', 'Programmatic')]
    [string]$Mode = 'Interactive',

    # Principal performing the self-add. Default = current security context.
    [string]$Principal,

    # OU subtree the scanner searches. EMPTY (default) -> the scanner derives the
    # running user's DOMAIN ROOT (RootDSE defaultNamingContext). Set this (or the JSON
    # searchBase) to tighten scope to an OU/DN per engagement-spec.
    [string]$SearchBase,

    # DC to pin. Empty -> the runner resolves + pins ONE explicitly (invariant 4).
    [string]$Server,

    # ARM the write. Without it the runner is dry-run end-to-end (scan + preview only).
    [switch]$Execute,

    # Programmatic mode: auto-run the cleaner after the writer (still journal-first).
    [switch]$AutoCleanup,

    # Override the journal location (default: next to this script, *.journal.json -> gitignored).
    [string]$JournalPath,

    # (v1.1) JSON run-config driving an unattended run. Explicit CLI params OVERRIDE the
    # JSON. CREDENTIALS ARE NEVER READ FROM JSON. See toolkit/run-config.example.json.
    [string]$ConfigPath,

    # (v1.1) Explicit LDAP bind credential for remote / portable use (WinRM double-hop,
    # where the integrated session can't delegate to the DC). Threaded into the scanner,
    # the writer, AND Resolve-PinnedDc (Secure SSPI bind). Omitted = integrated auth.
    [System.Management.Automation.PSCredential]$Credential
)

$ErrorActionPreference = 'Stop'   # poc-conventions.md rule 1: orchestrator is fully fail-fast; the writer's add is the lone scope-exempt primitive (captured below).

# --- layout self-check (fail FAST -- never blow through into cryptic downstream errors) -----
# This kit ALWAYS expects:  <dir>\runner.ps1  +  <dir>\config.json  +
#   <dir>\lib\{scanner,writer,cleaner,notify-jira}.ps1
# Verified here BEFORE anything is dot-sourced/parsed. If the layout is already correct this is
# silent; otherwise we exit 2 with a precise "what's missing" line (no half-run, no stack dumps).
$libDir = Join-Path $PSScriptRoot 'lib'
if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot 'config.json' }
$__need = @(
    @{ p = $libDir;                               what = 'lib\ (component directory)' },
    @{ p = (Join-Path $libDir 'notify-jira.ps1'); what = 'lib\notify-jira.ps1' },
    @{ p = (Join-Path $libDir 'scanner.ps1');     what = 'lib\scanner.ps1' },
    @{ p = (Join-Path $libDir 'writer.ps1');      what = 'lib\writer.ps1' },
    @{ p = (Join-Path $libDir 'cleaner.ps1');     what = 'lib\cleaner.ps1' },
    @{ p = $ConfigPath;                           what = (Split-Path -Leaf $ConfigPath) + ' (config, next to runner.ps1)' }
)
$__missing = @($__need | Where-Object { -not (Test-Path -LiteralPath $_.p) } | ForEach-Object { $_.what })
if ($__missing.Count -gt 0) {
    Write-Host "[runner] LAYOUT ERROR -- this kit expects runner.ps1 + config.json next to it + lib\{scanner,writer,cleaner,notify-jira}.ps1." -ForegroundColor Red
    Write-Host ("[runner] missing: " + ($__missing -join '; ')) -ForegroundColor Red
    Write-Host "[runner] fix: copy config.example.json -> config.json (next to runner.ps1); keep the components under lib\." -ForegroundColor Red
    exit 2
}

# --- dot-source the components (from lib\) -----------------------------------
. (Join-Path $libDir 'notify-jira.ps1')
. (Join-Path $libDir 'scanner.ps1')
. (Join-Path $libDir 'writer.ps1')
. (Join-Path $libDir 'cleaner.ps1')

# CRITICAL: each dot-sourced component has its OWN param() block. Dot-sourcing runs that
# param block in THIS scope with no args, so it RESETS our same-named variables ($Principal,
# $Server, $Credential, $SearchBase, $Execute, ...) to the components' defaults -- silently
# clobbering the runner's CLI-bound values. The JSON merge below only RE-applies params that
# were NOT passed on the CLI (it gates on $PSBoundParameters), so a CLI-passed -Principal /
# -Credential would otherwise be lost here and the writer would self-add the RUNNING identity
# instead of the intended actor. Restore every CLI-bound value from $PSBoundParameters now.
foreach ($k in @($PSBoundParameters.Keys)) { Set-Variable -Name $k -Value $PSBoundParameters[$k] }

function Read-HostRobust {
    # Read-Host wrapper that ALSO works under redirected stdin (piped selection for
    # automated testing). When the console host can't Read-Host (input redirected),
    # we fall back to [Console]::In.ReadLine(). Returns $null at EOF (treated as quit).
    param([string]$Prompt)
    try {
        if ([Console]::IsInputRedirected) {
            if ($Prompt) { Write-Host ($Prompt + ': ') -NoNewline }
            return [Console]::In.ReadLine()
        }
        return (Read-Host -Prompt $Prompt)
    } catch {
        # Last-ditch: a non-interactive host with no console at all -> read the stream.
        if ($Prompt) { Write-Host ($Prompt + ': ') -NoNewline }
        return [Console]::In.ReadLine()
    }
}

function ConvertTo-CliValue {
    # Map an "auto"/empty JSON token to $null (so the scanner's empty-means-derive
    # paths fire). Any other value passes through verbatim.
    param([string]$Value)
    if ($null -eq $Value) { return $null }
    $t = $Value.Trim()
    if ($t -eq '' -or $t -ieq 'auto') { return $null }
    return $Value
}

function Resolve-PinnedDc {
    # Resolve a SINGLE DC and return its name so modify + (any) capture bind to ONE DC.
    # Credential-aware (v1.1): with -Cred, the RootDSE bind uses AuthenticationTypes::Secure
    # so the locator read does NOT rely on session delegation (WinRM double-hop).
    param(
        [string]$Preferred,
        [System.Management.Automation.PSCredential]$Cred
    )
    if ($Preferred) { return $Preferred }
    # Serverless RootDSE bind -> the DC locator picks one; read back which one answered.
    if ($Cred) {
        $rootDse = New-Object System.DirectoryServices.DirectoryEntry('LDAP://RootDSE', $Cred.UserName, $Cred.GetNetworkCredential().Password, [System.DirectoryServices.AuthenticationTypes]::Secure)
    } else {
        $rootDse = New-Object System.DirectoryServices.DirectoryEntry('LDAP://RootDSE')
    }
    $dc = [string]$rootDse.Properties['dnsHostName'].Value
    if (-not $dc) { throw "runner: could not resolve a DC to pin (RootDSE dnsHostName empty)." }
    return $dc
}

function Select-Candidate {
    # (v1.1) Programmatic selection strategy. Picks the initial candidate from the
    # ranked list per the JSON selection block. Returns $null if no candidate matches
    # (caller treats that as "nothing to fire"). The runner's fall-through loop still
    # tries the remaining ranked candidates after this pick on a runtime write failure.
    #   top           -> highest-ranked (the v1.0 default).
    #   byName        -> candidate whose Name (sAMAccountName/CN) == value (case-insensitive).
    #   byDn          -> candidate whose DistinguishedName == value (case-insensitive).
    #   byRankAtLeast -> highest-ranked candidate with Rank >= value.
    param(
        [object[]]$Candidates,
        [string]$Strategy,
        [string]$Value
    )
    if (-not $Strategy) { $Strategy = 'top' }
    switch ($Strategy) {
        'top' { return $Candidates[0] }
        'byName' {
            foreach ($c in $Candidates) { if ([string]$c.Name -ieq $Value) { return $c } }
            return $null
        }
        'byDn' {
            foreach ($c in $Candidates) { if ([string]$c.DistinguishedName -ieq $Value) { return $c } }
            return $null
        }
        'byRankAtLeast' {
            $min = 0
            if (-not [int]::TryParse($Value, [ref]$min)) {
                throw "runner: selection.strategy=byRankAtLeast needs an integer value (got '$Value')."
            }
            # $Candidates is already rank-descending -> first one >= min is the highest.
            foreach ($c in $Candidates) { if ([int]$c.Rank -ge $min) { return $c } }
            return $null
        }
        default { throw "runner: unknown selection.strategy '$Strategy' (top|byName|byDn|byRankAtLeast)." }
    }
}

# --- load + merge the single config ------------------------------------------
# The config (layout-verified above) carries the runner settings AND the optional jira{} block.
# Explicit CLI params OVERRIDE the config (detected via $PSBoundParameters, so a deliberate CLI
# value wins even if it equals a default). CREDENTIALS for the actor are NEVER read from the
# config (the -Credential param is the only cred surface).
$selStrategy = 'top'
$selValue    = ''
$cfg = $null
if ($ConfigPath) {
    try {
        $cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
    } catch {
        throw "runner: config '$ConfigPath' is not valid JSON: $($_.Exception.Message)"
    }
    Write-Host "[runner] loaded config: $ConfigPath" -ForegroundColor DarkGray

    $hasProp = { param($o, $n) ($o.PSObject.Properties.Name -contains $n) }

    if (-not $PSBoundParameters.ContainsKey('Mode')       -and (& $hasProp $cfg 'mode')       -and $cfg.mode) {
        $candMode = ([string]$cfg.mode).Trim()
        # Accept lower-case JSON tokens; normalize to the ValidateSet casing.
        if ($candMode -ieq 'programmatic') { $Mode = 'Programmatic' }
        elseif ($candMode -ieq 'interactive') { $Mode = 'Interactive' }
        else { throw "runner: run-config mode '$candMode' invalid (programmatic|interactive)." }
    }
    if (-not $PSBoundParameters.ContainsKey('Principal')  -and (& $hasProp $cfg 'principal')) {
        $Principal = ConvertTo-CliValue ([string]$cfg.principal)
    }
    if (-not $PSBoundParameters.ContainsKey('SearchBase') -and (& $hasProp $cfg 'searchBase')) {
        $SearchBase = ConvertTo-CliValue ([string]$cfg.searchBase)
    }
    if (-not $PSBoundParameters.ContainsKey('Server')     -and (& $hasProp $cfg 'server')) {
        $Server = ConvertTo-CliValue ([string]$cfg.server)
    }
    if (-not $PSBoundParameters.ContainsKey('Execute')    -and (& $hasProp $cfg 'execute')) {
        if ([bool]$cfg.execute) { $Execute = [switch]$true }
    }
    if (-not $PSBoundParameters.ContainsKey('AutoCleanup') -and (& $hasProp $cfg 'autoCleanup')) {
        if ([bool]$cfg.autoCleanup) { $AutoCleanup = [switch]$true }
    }
    if ((& $hasProp $cfg 'selection') -and $cfg.selection) {
        if (($cfg.selection.PSObject.Properties.Name -contains 'strategy') -and $cfg.selection.strategy) {
            $selStrategy = ([string]$cfg.selection.strategy).Trim()
        }
        if ($cfg.selection.PSObject.Properties.Name -contains 'value') {
            $selValue = [string]$cfg.selection.value
        }
    }
}

Write-Host "=== WF2025.4142 trigger runner (mode=$Mode, execute=$($Execute.IsPresent)) ===" -ForegroundColor Cyan
if ($Credential) {
    Write-Host "[runner] explicit -Credential supplied (user=$($Credential.UserName)) -> remote/portable bind (Secure SSPI)." -ForegroundColor DarkGray
}
if (-not $Execute) {
    Write-Host "[runner] DRY-RUN (default). No AD write will occur. Pass -Execute to arm the self-add." -ForegroundColor Yellow
}
# Auto-domain: empty/auto SearchBase -> scanner derives the running user's domain root.
if (-not $SearchBase) {
    Write-Host "[runner] search base = AUTO (running user's domain root via RootDSE defaultNamingContext)." -ForegroundColor DarkGray
}

# --- JIRA pre-flight: BEFORE any AD touch (invariant -- notify-jira contract) -
# The jira{} block lives in the single config. Assert-JiraReady returns $false ONLY when LIVE
# (dry_run:false) AND the /myself probe fails -> abort before firing so we never
# fire-and-fail-to-record. No jira block / dry-run -> $true (proceed). The whole config object
# is passed (Send-JiraComment reads $cfg.jira.* + $cfg.rule_name + $cfg.debug).
$JiraCfg = $null
if ($cfg -and ($cfg.PSObject.Properties.Name -contains 'jira') -and $cfg.jira) {
    $jiraOk = $true
    foreach ($jk in @('base_url','issue_key','pat','dry_run')) {
        if (-not ($cfg.jira.PSObject.Properties.Name -contains $jk)) { $jiraOk = $false; break }
    }
    if ($jiraOk) { $JiraCfg = $cfg }
    else { Write-Host "[runner] config jira{} block incomplete (need base_url/issue_key/pat/dry_run) -- JIRA notify disabled." -ForegroundColor Yellow }
}
if (-not (Assert-JiraReady -Config $JiraCfg)) {
    Write-Host "[runner] ABORT: JIRA configured LIVE but /myself auth probe failed. Not touching AD (fix creds or set jira.dry_run=true)." -ForegroundColor Red
    exit 3
}

# --- pin ONE DC (invariant 4) ------------------------------------------------
$pinnedDc = Resolve-PinnedDc -Preferred $Server -Cred $Credential
Write-Host "[runner] pinned DC: $pinnedDc" -ForegroundColor DarkGray

# --- SCAN (read-only) --------------------------------------------------------
# Empty $SearchBase passes through to the scanner, which derives the domain root.
$scanScope = if ($SearchBase) { $SearchBase } else { '(domain root / auto)' }
Write-Host "[runner] scanning '$scanScope' for self-addable security-enabled GLOBAL groups..." -ForegroundColor Cyan
$candidates = @(Find-SelfAddableGroups -Principal $Principal -SearchBase $SearchBase -Server $pinnedDc -Credential $Credential)
if (-not $candidates -or $candidates.Count -eq 0) {
    Write-Host "[runner] no self-addable candidates found. Nothing to fire. (Scanner is read-only; AD untouched.)" -ForegroundColor Yellow
    exit 0
}
Write-Host "[runner] $($candidates.Count) ranked candidate(s):" -ForegroundColor Green
$candidates | Format-Table Rank, RightClass, Name, DistinguishedName -AutoSize

# --- PICK --------------------------------------------------------------------
$chosen = $null
if ($Mode -eq 'Interactive') {
    # (B) interactive: clear numbered list (index, rank, right-class, name, DN).
    Write-Host ""
    Write-Host ("  {0,-4} {1,-5} {2,-42} {3,-24} {4}" -f 'idx', 'rank', 'right-class', 'name', 'DN') -ForegroundColor DarkGray
    $idx = 0
    foreach ($c in $candidates) {
        Write-Host ("  [{0,-2}] {1,-5} {2,-42} {3,-24} {4}" -f $idx, $c.Rank, $c.RightClass, $c.Name, $c.DistinguishedName)
        $idx++
    }
    Write-Host ""
    $sel = Read-HostRobust -Prompt "Select candidate index to self-add to (or 'q' to quit)"
    if ($null -eq $sel -or $sel.Trim() -ieq 'q') {
        Write-Host "[runner] aborted by operator (or EOF on redirected input). AD untouched." -ForegroundColor Yellow
        exit 0
    }
    $selInt = 0
    if (-not [int]::TryParse($sel.Trim(), [ref]$selInt) -or $selInt -lt 0 -or $selInt -ge $candidates.Count) {
        throw "runner: invalid selection '$sel' (expected 0..$($candidates.Count - 1) or 'q')."
    }
    $chosen = $candidates[$selInt]
    Write-Host "[runner] selected [#$selInt]: rank $($chosen.Rank) $($chosen.RightClass) -> $($chosen.DistinguishedName)" -ForegroundColor Cyan

    # Confirm BEFORE any write (dry-run still previews via the writer; this is the arm gate).
    if ($Execute) {
        $conf = Read-HostRobust -Prompt "ARM the self-add write to this group now? (y/N)"
        if ($null -eq $conf -or $conf.Trim() -notmatch '^[Yy]') {
            Write-Host "[runner] write not confirmed -> downgrading to DRY-RUN preview only. AD untouched." -ForegroundColor Yellow
            $Execute = [switch]$false
        }
    }
} else {
    # (A) programmatic: pick per the selection strategy; the writer falls through if it fails.
    $chosen = Select-Candidate -Candidates $candidates -Strategy $selStrategy -Value $selValue
    if (-not $chosen) {
        Write-Host "[runner] programmatic selection (strategy=$selStrategy, value='$selValue') matched NO candidate. Nothing to fire. AD untouched." -ForegroundColor Yellow
        exit 0
    }
    Write-Host "[runner] programmatic mode (strategy=$selStrategy) -> candidate: rank $($chosen.Rank) $($chosen.DistinguishedName)" -ForegroundColor DarkGray
}

# --- resolve journal path (gitignored *.journal.json) ------------------------
if (-not $JournalPath) { $JournalPath = Join-Path $PSScriptRoot 'wf2025-4142.journal.json' }

# --- writer fall-through loop (scanner output = ranked candidates, NOT guarantees) ---
# Try the chosen candidate; on a runtime write failure / already-member, fall through
# to the next-ranked candidate (programmatic) -- writer asserts every invariant itself.
$order = New-Object System.Collections.Generic.List[object]
$order.Add($chosen)
if ($Mode -eq 'Programmatic') {
    foreach ($c in $candidates) { if ($c.DistinguishedName -ne $chosen.DistinguishedName) { $order.Add($c) } }
}

# PS5.1-compatible actor DN (no ternary -- ternary is PS7-only). With -Credential the
# acting identity is the credential's user; else the current security context.
$actorDnForJournal = if ($Principal) {
    $Principal
} elseif ($Credential) {
    $Credential.UserName
} else {
    [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
}

$writerResult = $null
foreach ($cand in $order) {
    Write-Host "[runner] target: $($cand.DistinguishedName) (rank $($cand.Rank), $($cand.RightClass))" -ForegroundColor Cyan

    # JOURNAL FIRST (invariant 5) -- written BEFORE the write, even in dry-run, so an
    # interrupted armed run is recoverable. We record was-already-member after a probe.
    # The writer also re-probes was-already-member; here we journal the plan up front.
    $journal = Write-CleanupJournal -Path $JournalPath `
        -GroupObjectGuid $cand.ObjectGuid -GroupDn $cand.DistinguishedName `
        -ActorSid $cand.PrincipalSid -ActorDn $actorDnForJournal `
        -WasAlreadyMember $false -Server $pinnedDc

    # WRITE (the lone primitive) -- captured try/catch (poc-conventions.md rule 1).
    $writerRc = 0
    try {
        $writerResult = Invoke-SelfAdd -GroupDn $cand.DistinguishedName -Member $Principal `
            -Server $pinnedDc -Credential $Credential -Execute:$Execute
        $writerRc = $writerResult.ExitCode
    } catch {
        $writerRc = 1
        Write-Warning "[runner] writer threw on '$($cand.DistinguishedName)' (captured): $($_.Exception.Message)"
    }

    # If the writer found the actor was ALREADY a member, correct the journal so a
    # later cleanup treats member-as-baseline (no spurious removal of a pre-existing member).
    if ($writerResult -and $writerResult.WasAlreadyMember) {
        $journal.was_already_member = $true
        $journal | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $JournalPath -Encoding ASCII
    }

    # Backfill the journal's actor_dn with the writer's RESOLVED member DN. Up front the runner
    # only had the principal in DOMAIN\sam / UPN form, but AD stores group members as DNs, so the
    # cleaner's membership check (DN vs DN) would otherwise miss and falsely report "already
    # absent" -> no revert. The writer resolved the true DN; persist it for the cleaner.
    if ($writerResult -and $writerResult.MemberDn) {
        $journal.actor_dn = $writerResult.MemberDn
        $journal | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $JournalPath -Encoding ASCII
    }

    if ($writerResult -and $writerResult.Status -eq 'AlreadyMember' -and $Mode -eq 'Programmatic') {
        Write-Host "[runner] already-member on this candidate -> falling through to next." -ForegroundColor Yellow
        $writerResult = $null
        continue
    }
    if ($writerRc -eq 0) { break }   # success (write or dry-run preview) -- stop falling through.
    if ($Mode -ne 'Programmatic') { break }   # interactive: don't auto-fall-through.
}

# --- JIRA execution record AFTER the writer fires (invariant 1 wiring) --------
# Send-JiraComment is config-gated + dry-run-gated: no config -> no-op; dry_run:true
# -> build + preview, NO POST. It records the writer's 4728 execution.
$writerRcForJira = if ($writerResult) { $writerResult.ExitCode } else { 1 }
Send-JiraComment -Config $JiraCfg -Artifact (Join-Path $libDir 'writer.ps1') -ExitCode $writerRcForJira

# --- report + cleanup offer --------------------------------------------------
if ($writerResult) {
    Write-Host "[runner] writer status: $($writerResult.Status) (Subject==Member: $($writerResult.SubjectSid -eq $writerResult.MemberSid))" -ForegroundColor Green
}

if ($Execute -and $writerResult -and $writerResult.Fired4728) {
    if ($Mode -eq 'Programmatic') {
        if ($AutoCleanup) {
            Write-Host "[runner] -AutoCleanup -> reverting via cleaner (journal-driven)." -ForegroundColor Cyan
            Invoke-Cleanup -JournalPath $JournalPath -Server $pinnedDc -Credential $Credential | Out-Null
        } else {
            Write-Host "[runner] write committed. Run cleanup with: cleaner.ps1 -JournalPath '$JournalPath'" -ForegroundColor Yellow
        }
    } else {
        $ans = Read-HostRobust -Prompt "Revert the self-add now via the cleaner? (y/N)"
        if ($null -ne $ans -and $ans.Trim() -match '^[Yy]') {
            Invoke-Cleanup -JournalPath $JournalPath -Server $pinnedDc -Credential $Credential | Out-Null
        } else {
            Write-Host "[runner] left in place. Revert later with: cleaner.ps1 -JournalPath '$JournalPath'" -ForegroundColor Yellow
        }
    }
}

Write-Host "=== runner done ===" -ForegroundColor Cyan
exit $writerRcForJira
