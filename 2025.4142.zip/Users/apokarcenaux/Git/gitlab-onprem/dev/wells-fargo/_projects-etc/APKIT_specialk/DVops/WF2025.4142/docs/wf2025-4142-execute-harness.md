# execute harness — WF2025.4142

> **v2 autobuild execute-type harness** (`skills/autobuild.md §1.4` / §2.1; carries the two durable stability surfaces — the cron heartbeat + the `/goal` block).
> **scope:** plan→execute handoff for the WF2025.4142 minimum-trigger PoC. Authored during the v2 realignment of the fossil-staged session-1 plan.
> **companion artifacts:** SoT spec `engagement-spec.md` + `_intake/wf2025-4142-refined.md` · gitlab `dev/wf/projects-etc/apkit_specialk/dvops/wf2025.4142` (gitlab.4p0k.com) · epic **&2** "WF2025.4142 — minimum trigger PoC" · milestone **M1 (id 172)** "M1: trigger + validate" · DB plan `autobuild-wf2025-4142` (active) · workload **10** (`dvops-jun-2026-2025-4142`, active) · primary/design issue **#1** · impl **#3** · gates **#2 #4 #6 #5**.

## operating model

- **leader-operated (never delegated):** #1 design note + all gate verdicts (#2 design-confirm, #4 testlab, #6 ship-gate, #5 v1-value) + any AD-lab credential/vault touch. Gate verdicts MUST quote real tool output (anti-cheat acceptance).
- **sub-agent-dispatched:** #3 impl only — build the runner/scanner/writer/cleaner + JIRA dry-run wiring, seed the lab fixture, run the Win10/11×PS5.1/PS7 matrix as `Austin.Powers`, capture the 4728, **commit direct to rule-repo `main`** (one issue per dispatch; STATE OVERRIDES table + anti-cheat citation mandatory in the brief).
- **dvops carve-out:** direct-push to this rule-repo `main` — no feature branch, no MR. Autobuild AP#3 (branch-protection) is scoped to apkit/spine `main`, NOT dvops rule-repos.
- **cron heartbeat:** read-mostly; never spawns sub-agents, never advances the DAG.

## DAG (M1, linear)

`#1 design → #2 [GATE] min-viable-trigger → #3 impl-toolkit+lab → #4 [GATE] testlab-fired → #6 [GATE] shipped-toolkit-preflight → #5 [GATE] v1.0.0 ship-readiness`

## cron heartbeat (paste at execute-boot)

```
/loop 15m heartbeat for the WF2025.4142 dvops v1 autonomous build. read-mostly re-orientation, no destructive actions.

0. /pop FIRST — load status.md + CLAUDE.md + MEMORY.md + this harness doc + workload context (every tick, including post-compact, uses this same boot path)
1. /cp quick to re-read the gitlab active milestone (epic &2 "WF2025.4142 — minimum trigger PoC", milestone M1 id 172 "M1: trigger + validate"), workfile state, recent activity, and drift between db and gitlab labels
2. read .apkit/.session-env.sh to confirm APKIT_SESSION_ID + APKIT_AGENT_ID + APKIT_WORKLOAD_ID + APKIT_DB_PATH are intact
3. read MEMORY.md (auto memory) for any new entries since boot — especially feedback memories
4. check TaskList for active sub-agent runs — if any in_progress, log "sub-agent {name} active on issue #{N}" and DO NOTHING else this tick
5. if /cp reports drift (db status::* mismatches gitlab labels, OR workload status diverges from branch commits, OR DAG order violation): log the drift summary to .apkit/heartbeat.log, do NOT auto-fix — leader addresses on next active turn
6. if main session is genuinely idle (no sub-agent active, no /cp drift): this tick is a no-op other than the refresh

constraints:
- do NOT spawn sub-agents via Agent tool
- do NOT close issues or change labels
- do NOT run the runner/scanner/writer/cleaner against live AD, do NOT fire event 4728, do NOT touch any AD group membership or the testlab-sim
- do NOT push code or modify the filesystem outside .apkit/heartbeat.log
- do NOT engage with the user — heartbeat is silent unless drift is detected
- do NOT advance the autobuild DAG (no issue creation, no label flips, no gate close)
```
─── END CRON HEARTBEAT ───

## /goal block (paste at execute-boot — single condition for /goal)

per [code.claude.com/docs/en/goal](https://code.claude.com/docs/en/goal): /goal takes ONE condition string up to 4000 chars. The evaluator (small fast model) reads the conversation transcript and checks each turn — write the condition as something Claude can demonstrate via tool output it surfaces. **The operator pastes the literal block below at execute-boot (and re-pastes verbatim after any /compact). The leader cannot fire /goal — it is a CC UI command, not a skill.** /goal auto-clears when the evaluator confirms shipped.

```
/goal WF2025.4142 v1.0.0 ships when ALL hold and Claude has surfaced the proof in this conversation: (a) MCP list_issues with state=opened, project_path=dev/wf/projects-etc/apkit_specialk/dvops/wf2025.4142, milestone="M1: trigger + validate" returns [] (zero open issues remain in milestone M1); (b) `git tag --list v1.0.0` run in the rule repo /home/apok/claude-projects/specialk/_git-workspaces/wf2025-4142 prints exactly v1.0.0; (c) MCP get_issue returns state=closed for design #1 and impl #3; (d) MCP get_issue returns state=closed for ALL gate issues #2 ([GATE] minimum-viable trigger confirmed), #4 ([GATE] M1 testlab — trigger fired the rule), #6 ([GATE] shipped-toolkit preflight) and #5 ([GATE] v1.0.0 PoC ship readiness); (e) the #4 testlab PASS verdict quotes a real captured-4728 manual-SPL eval where SubjectUserSid==MemberSid AND src_nt_domain!="QA-ENT" AND user does-not-match ^r.* on a security-enabled global group — a validate.py EventID=4728-only match is a FAIL not a pass. Prove each turn by quoting the tool outputs verbatim. Constraints throughout the build: one issue per sub-agent dispatch (autobuild anti-pattern #7); every [GATE] verdict quotes real tool output (captured-4728 fields / git / MCP), never composed or assumed (anti-cheat acceptance); direct push to this dvops rule-repo main is ALLOWED and expected — no feature branch, no MR (anti-pattern #3 is scoped to apkit/spine main, NOT dvops rule-repos — do not over-restrict); [GATE]/testlab::gate issues #2 #4 #6 #5 are leader-only — never delegate gate verdicts to sub-agents (anti-patterns #4 #10); the v1.0.0 tag is refused while ANY gate issue (#2 #4 #6 #5) is still open (anti-pattern #6); wrapper-config.json stays dry_run:true the entire engagement (no live JIRA POST before #5 handoff). or stop after 300 turns.
```

evaluator references:
- transcript proofs surfaced via `mcp__apkit-gitlab__list_issues`, `mcp__apkit-gitlab__get_issue`, `git tag --list`, and the #4 captured-4728 manual-SPL eval verdict comment
- the manual SPL eval is a **leader/operator verdict** behind gate #4 — it is intentionally NOT an auto-judged `/goal` criterion (the evaluator reads no files/tools); /goal gates on the demonstrable facts (issues closed, tag exists, verdict comment present)
- on /compact: re-paste this block verbatim (the goal is restored by --resume/--continue but its turn counter resets)
- on early abort: `/goal clear`

## failure modes

| scenario | behavior |
|---|---|
| cron fires mid-write (sub-agent committing) | `/cp quick` is read-mostly; logs "deferred — write in progress", retries next tick |
| `/cp` reports drift | logs summary to `.apkit/heartbeat.log`, does NOT auto-reconcile; leader addresses next active turn |
| main session genuinely idle | no-op other than the `/cp` refresh |
| sub-agent crashed mid-issue (status in_progress but stale) | heartbeat logs "stale sub-agent {name}"; leader cleans up next turn |
| heartbeat itself errors | `/loop` retries next interval; 3 consecutive failures → leader investigates |
| **#4 testlab-sim does not fire 4728 on first run** | file `type::bug` linked `relates_to #4`, run step-back (2 orthogonal angles) before escalation, re-run gate (hotfix→retest, 3-strike per §4.1) |
| **RSAT accidentally present on the dev host, masking the RSAT-free requirement** | leader flags; validate on a clean stock endpoint (the #6 check-1 surface) |
| **manual SPL eval ambiguous** | leader surfaces to operator — manual eval is a human verdict, not auto-gradable |

## stopping

ship moment = **#5 "[GATE] v1.0.0 PoC ship readiness" closes + `v1.0.0` tag on rule-repo `main`**. Then:
1. log "loop stopped — WF2025.4142 shipped at <ts>" to `.apkit/heartbeat.log`
2. `/loop stop`; confirm the next 15-min mark passes without firing
3. **update this rule-repo's `STATUS.md`** (spine CLAUDE.md rule-repo hook — mandatory on `/stash` or `/cp` from inside this cwd)
4. `/stash` final summary; workload **10** flips to `closed`

## pre-flight (execute-readiness dry-run — AP#12)

before the first dispatch, the leader confirms inline-quoted: `APKIT_WORKLOAD_ID` non-empty; workload **10** status `active` (NOT paused — SessionStart only exports the var for active workloads); each gate's verdict MCP query (`get_comments`/`list_issue_links`) returns the expected tokens; this doc's `/goal` block is byte-identical to what `/goal`-eval will check.

## cross-references

- `skills/autobuild.md` (apkit v2) — §1.4 phase D, §2.1 execute boot, §3 ship-gates, §4 step-back, anti-patterns #6/#7/#10/#17/#18/#19
- `templates/autobuild/{cron-heartbeat-prompt,goal-block-template}.md`
- `engagement-spec.md` + `_intake/wf2025-4142-refined.md` — the design + refined-idea SoT
- spine `CLAUDE.md` — dvops rule-repo workflow (STATUS.md on-entry/on-exit hook)
