# STATUS — WF2025.4142

_last updated: 2026-06-01 (full runner.ps1 VALIDATED on Win10 modes A+B + 4 hotfixes + proxy-aware; W11 full-runner + tag remain)_

## next step
**Win10 full-runner is DONE; remaining for `v1.1.0`: run the (now-fixed) full runner on W11, then commit + tag.** The full `runner.ps1` orchestrator now runs end-to-end on `W10-CORP-04` in BOTH drive modes — A programmatic/JSON via a batch scheduled-task, B interactive by keyboard over RDP — RSAT-free, firing a real `Austin.Powers → dvops-4142-grp` 4728 and auto-reverting to baseline (see "v1.1 — full runner" below + `validation-proof.md`). This required **four orchestrator hotfixes** (the runner had never been run end-to-end credentialed/non-interactively before, only its standalone components):
1. `writer.ps1` mandatory-param dot-source hang, 2. `runner.ps1` dot-source param clobber, 3. `cleaner.ps1` GUID-bind-under-credential, 4. `runner.ps1` journal actor_dn sam-vs-DN.
The JIRA egress is now **natively Win10-proxy-aware** (validated: system-WinINET + explicit override, SSO proxy auth; AD work is direct LDAP). README gained a "what's needed to go" quick-start.

**Kit layout cleaned up (consolidation):** ONE co-located `config.json` (runner settings + the `jira{}` block merged — no separate `wrapper-config.json`/`jiraConfigPath`); components moved to `lib\`; runner does a **fail-fast layout self-check** on start (exits 2 with a precise "missing" line if `config.json` or any `lib\` component is absent). README condensed to the MVP full-auto+JIRA config + the two run modes. Re-validated end-to-end on W10 (parse-clean; rc=0; baseline restored).
- **remaining:** (1) run the fixed full runner on `W11-CORP-02` for #7's dual-host clause; (2) ~~commit toolkit fixes + proxy + README/docs to `main`~~ (this push); (3) tag `v1.1.0`, close #7.
- **prior "harness-blocked" note — RESOLVED/misdiagnosis:** the "full runner over WinRM 400s / session-0 stall" was actually (a) the writer mandatory-param dot-source prompt hanging any non-interactive host, and (b) the driver using `operation_timeout > MaxTimeoutms`. Both fixed; the full runner runs fine via batch scheduled-task and by hand over RDP.

**Endpoint left ready for hands-on:** `W10-CORP-04` has RDP enabled + `ECORP\Austin.Powers` in Remote Desktop Users; toolkit staged at `C:\Windows\Temp\wf4142` with the actor granted Modify; `dvops-4142-grp` fixture seeded (0 members, Self-ACE). **To revert at engagement end:** disable RDP (`fDenyTSConnections=1` + disable the RDP firewall group), remove the RDP-Users add, tear down the fixture, remove the toolkit drop.

**Test harness** (beachhead `vm_5002`, `~/wf4142/`): `wf4142_run.py` (actions: scan/seed/write/runner/runnerasync/runnerdry/winrmboost) + `dc01_ops.py` (probe/seed/capture/cleanup on dc-01 via integrated admin) + `run-config*.json` + helpers added this session (`wf4142_probe.py`, `wf4142_cleanup_w11.py`, `dc_baseline.py`, `dc_investigate.py`). Access: `ssh bh` via SSH_ASKPASS (sshpass absent); pywinrm + smbclient on beachhead; ldap3-NTLM broken (OpenSSL3 removed MD4). Cred: vault `vm-5001-pass` (beachhead); DC/actor creds inline (lab).

**✓ cleanup DONE (2026-06-01):** W11 + W10 fully reverted to baseline — `C:\Windows\Temp\wf4142` removed on both (incl. `runner-wrap.ps1` which held the Austin.Powers pw), scheduled task `wf4142run` unregistered (W11), `MaxTimeoutms`/`MaxEnvelopeSizekb` reverted to 60000/500 (W11). DC: `dvops-4142-grp` deleted — also cleared a **v1.0.0 lingering-empty-group residual** (the prior teardown removed the member but left the group+Self-ACE), Austin.Powers de-membered → `BASELINE_RESTORED`. (`Operator` membership confirmed baseline lab config — 48 users, created 2024-09-11, no Self-ACE — untouched.)

## v1.1 — Win10 e2e VALIDATED 2026-06-01
**Minimum-primitive trigger PASS on `W10-CORP-04` (10.0.2.104, Win10 Ent, PS 5.1.19041.6456).** Standalone-component chain from the beachhead (dodges the long-command 400):
- **scanner** (RSAT-free, `-Credential`) ranked the one self-add candidate `dvops-4142-grp` (rank 60, Self-membership), `PrincipalSid …-1330` = Austin.Powers — rc=0, no RSAT present.
- **writer** (`-Credential -Execute`) self-added Austin.Powers: `Status=Added`, `SubjectSid==MemberSid` (`…-1330`), `WasAlreadyMember=False`, `Fired4728=True`.
- **4728 captured** from `dc-01` Security log: `TimeCreated=2026-06-01T10:33:38-07:00`, `SubjectUserName=Austin.Powers`, `SubjectDomainName=ECORP`, `SubjectUserSid==MemberSid`, `TargetUserName=dvops-4142-grp`. Manual SPL eval vs WF2025.4142: EventID=4728 ✓, src_nt_domain≠QA-ENT ✓, self-add ✓, user≠`^r.*` ✓, security-enabled global ✓ → **PASS**.
- **teardown**: member removed + group deleted → `BASELINE_RESTORED`; W10 toolkit drop removed.

This closes the documented Win10 gap (v1.0.0 had only scanner-RSAT-free on Win10, no 4728 — same RSAT-free `System.DirectoryServices` writer code as the Win11 primary, now proven to fire on Win10). **Now also proven:** the full `runner.ps1` orchestrator (modes A+B) on Win10 — see below.

## v1.1 — full runner ORCHESTRATOR VALIDATED on Win10 2026-06-01
**The full `runner.ps1` chain ran end-to-end on `W10-CORP-04`, RSAT-free, BOTH drive modes, real 4728, baseline-restored.** Full detail in `validation-proof.md`; summary:
- **Mode A** (programmatic/JSON, batch scheduled-task): scan→pick(byName)→journal→**write (Austin.Powers→dvops-4142-grp, 4728 fired, Subject==Member)**→JIRA dry-run→autoCleanup revert; `RUNNER_EXIT rc=0`; post-run members=0. Captured 4728 `2026-06-01T11:47:55` PASS.
- **Mode B** (interactive): driven by keyboard over RDP at the endpoint (pick candidate → arm → revert).
- **4 orchestrator hotfixes** (all in this push): writer mandatory-param dot-source hang; runner dot-source param clobber (was self-adding the running identity, not the actor); cleaner GUID-bind-under-credential (DN fallback); runner journal actor_dn sam→DN backfill.
- **proxy-aware:** `notify-jira.ps1` JIRA egress now honors the Win10 system (WinINET) proxy + explicit `jira.proxy`, with SSO proxy auth — validated on W10. AD work is direct LDAP, never proxied.

---

## v1.0.0 — SHIPPED 2026-05-29
**🚢 Engagement complete.** The RSAT-free toolkit fired a real Windows event **4728** (`SubjectUserSid==MemberSid`) on the `ecorp.com` lab; manual SPL eval PASS against every WF2025.4142 predicate; DC reverted to baseline. All M1 issues closed (`#1`–`#6`); milestone M1 closed; epic `&2` annotated SHIPPED; `v1.0.0` tag on rule-repo `main` (`6541259`).

**Deliverable** (rule-repo `main`): `toolkit/` (runner→scanner→writer→cleaner + `notify-jira.ps1` + `wrapper-config.example.json` + `validate.py`), `validation-proof.md` + `validation-artifacts/`, `_intake/wf2025-4142-refined.md`, `docs/wf2025-4142-execute-harness.md`.

**Validation summary:** scanner detected the seeded misconfig RSAT-free on stock Win11 (`rank 60`) + ran on Win10; writer self-added Austin.Powers → real 4728 captured on `dc-01`; cleaner reverted to baseline. 4 hardening commits surfaced live (`16a8960` `880e66b` `54c1158` `d0aeb5c`).

**Residuals (non-blocking):** PS7 matrix leg not provisioned (code is `#requires -Version 5.1`, PS7-compatible). `dvops-op-template` predates the v2 refine/`/goal`/ship-gate layering — candidate evolve pass so future dvops builds don't re-inherit the fossil gap. JIRA stayed `dry_run:true` all engagement (live POST never flipped).

_(validation reference — testlab-sim + manual SPL eval; trigger proven e2e in Phase-B + re-proven by the toolkit in M1.)_

## phase-B — trigger VALIDATED 2026-05-29
- **domain:** `ecorp.com` / NetBIOS `ECORP` / DC `dc-01` (10.0.1.10). Admin `ECORP\Administrator` / `P@55w0rd!!` works (WinRM 5985 + LDAP + ADWS 9389 all open from beachhead).
- **audit:** `Security Group Management = Success` ALREADY enabled on DC → 4728 logs natively (no audit-policy change made).
- **actor:** `Austin.Powers` / `PowersPass` (validated bind; non-priv normal user; not `^r.*`). Scheme `First.Last`/`LastNamePass` confirmed.
- **trigger run (then fully reverted):** created temp global-security group `dvops-4142-grp` (OU=ecorp-Groups) → delegated actor the Self-Membership validated-write ACE → actor self-added via LDAP from beachhead → **event 4728 generated** → captured via WinRM Get-WinEvent → group deleted (ACE gone, actor back to baseline). DC left clean.
- **captured 4728 vs SPL:** EventID=4728 ✓; SubjectDomainName=ECORP (≠ QA-ENT) ✓; Subject SID == Member SID (self-add) ✓; member `Austin.Powers` not `^r.*` ✓; security-enabled **global** group ✓. **Matches the rule.**
- **beachhead tooling added:** ldap-utils, smbclient, dnsutils, system python3-ldap3; venv `/opt/adenv` with `pywinrm`+`ldap3`. Helper scripts in `/root` on vm_5002.

## ingress — ESTABLISHED 2026-06-05
- **beachhead:** `vm_5002` / `ecorp-jump1` (Ubuntu 24, px1), cloned from `vm_5001` via clone + offline-migrate px3→px1 (PVE API, token `cicd@pve!cicd` + granted VM.Migrate).
- **dual-homed:** net0 `192.168.200.60` (vmbr0, mgmt — `ssh apok@192.168.200.60` from specialk) + net1 `10.0.1.60` (ecorpSvr1, L2-adjacent to DC1). default route = mgmt; `10.0.0.0/16` via ecorp gw `10.0.1.1`; DNS → DC1.
- **access PROVEN:** from the beachhead, DC1 `10.0.1.10` SMB/445, LDAP/389, RPC/135, Kerberos/88, DNS/53 all OPEN — the exact ports that are firewall-filtered when reached from specialk directly. This is the access primitive for triggering event 4728.
- persistent: netplan `90-beachhead.yaml`, cloud-init net-config disabled, `onboot=1`. identity (hostname/machine-id/ssh host keys) regenerated on clone. full host detail in spine `reference/lab-inventory.json` → `vm_5002`.
- creds: `apok` / vault `vm-5001-pass` (inherited from source clone).

## rule (from seeded README)
**WF2025.4142 — Non_Privilege_User_Adding_Themselves_To_An_AD_Group.** A non-privileged domain user adds their **own** account to a security-enabled **global** group → Windows event **4728**.
- SPL predicate: `index="os_short"`, `sourcetype=WinEventLog|XmlWinEventLog`, `EventID=4728`, `src_nt_domain!="QA-ENT"`, `SubjectUserName==user` (self-add), `user !~ ^r.*`, non-priv actor.
- **Validation path: testlab-sim** (non-CS log source — Windows Event Log → Splunk).
- Product: Splunk ES / RBA (finding risk 60; tenant notable threshold 100 — but dvops fires **once**, no risk-gaming).
- Trigger primitive (phase B): non-priv `First.Last` adds self to a global sec group → 4728. Three scripts: enumerate-condition → add → cleanup.

## lab — px1 "ecorp" enterprise lab (recon complete 2026-06-05)
- **DC:** `ecorp-DC1` (vmid 300), Server 2019, on bridge `ecorpSvr1`, **IP 10.0.1.10/24**, gw 10.0.1.1.
- **server subnet:** `10.0.1.0/24` (router 220 eth1). Workstation subnets: `10.0.2.0/24` (EcorpWks1), `10.0.3.0/24` (EcorpWks2).
- **gateways:** `ecorp-router` (220, inter-VLAN: eth0 10.0.0.2/29, eth1 10.0.1.1, eth2 10.0.2.1, eth3 10.0.3.1), `ecorp-firewall` (221, EcorpWAN/ecorpLAN/EcorpDMZ).
- **ingress:** RESOLVED — via beachhead `vm_5002` on `ecorpSvr1` (see ingress section). specialk itself has only routed/filtered reach (DNS/53 to DC only); all SMB/LDAP work runs from the beachhead.
- **ecorp 10.0.1.0/24 occupancy (ARP-confirmed 2026-06-05):** `.1` gw, `.10` DC1, `.50` ecorp-exch, `.60` = beachhead (was free). `.61`–`.65` free. (ecorp-fs/firewall LAN IPs not on .60-.65.)
- **fleet:** ecorp-exch(301), ecorp-fs(307), ecorp-WWW(310), Win servers 2012r2→2022 (302-306), w10/w11 corp+aggr workstations (321-339), RHEL (501/503/504), macOS(600).
- **bridges (px1, internal except vmbr0):** vmbr0(mgmt 192.168.200.10/24), ecorpLAN, ecorpSvr1, EcorpWks1/2/3, EcorpDMZ, EcorpTaskr, ecorpRed, EcorpWAN(uplink ens2f1), nowhere.

## creds (from VM descriptions — to be tested + vaulted)
- **local admin (all hosts):** `Administrator` / `P@55w0rd!!`
- **domain users** (OU `ecorp-accounts`): `First.Last` / `LastNamePass` (e.g. John.Doe / DoePass) ← **non-priv actor source** (pick first-name NOT starting with `r`)
- **domain admins** (OU `ecorp-admins`): `First.Last.Adm` / `LastNameAdmin`

## open follow-ups
- **Splunk-side validation** — confirm the 4728 reaches `index=os_short` (sourcetype `WinEventLog`/`XmlWinEventLog`) and WF2025.4142 fires (detection handoff / needs Splunk access). Field-level SPL match already proven; ingestion/rule-fire not yet confirmed.
- package the reproducible trigger as the dvops deliverable: `engagement-spec.md` + 3 scripts (setup-precondition → self-add → cleanup), then `/autobuild` → `/intake #<primary>` to bind the workload.
- _done:_ domain name (ecorp.com/ECORP), user+group enumeration, audit-already-on confirmation, AD tooling on beachhead, group+delegation+self-add+4728-capture+cleanup.

## blockers
- ~~ingress to ecorp segment~~ — **RESOLVED** via beachhead `vm_5002`.
- ~~beachhead apt/tooling egress~~ — **CONFIRMED working** (archive.ubuntu.com reachable; DC forwards external DNS).
- none hard. Remaining work is Splunk-side validation + packaging.
